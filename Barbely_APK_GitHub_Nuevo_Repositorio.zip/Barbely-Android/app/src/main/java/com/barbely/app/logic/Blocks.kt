package com.barbely.app.logic

/**
 * Bloqueos de horario (equivalente a bloqueosStore.cells de la app original).
 *
 * Cada cita ocupa celdas de 15 minutos. Cada celda es un documento de la colección "bloqueos" con
 * id fijo "barbero_fecha_HHmm": si dos clientes intentan reservar la misma hora, el segundo
 * encuentra el documento ya creado y la reserva se rechaza completa.
 */
const val BLOCK_MINUTES = 15

data class BlockCell(val id: String, val hora: String)

/** Celdas de 15 min que ocupa una cita de [horaInicio] a [horaFin]. */
fun blockCells(barberoId: String, fecha: String, horaInicio: String, horaFin: String): List<BlockCell> {
    val out = ArrayList<BlockCell>()
    val end = timeToMinutes(horaFin)
    var minute = (timeToMinutes(horaInicio) / BLOCK_MINUTES) * BLOCK_MINUTES
    while (minute < end) {
        val hora = minutesToTime(minute)
        out.add(BlockCell(id = "${barberoId}_${fecha}_${hora.replace(":", "")}", hora = hora))
        minute += BLOCK_MINUTES
    }
    return out
}
