package com.barbely.app.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.barbely.app.data.AppointmentStatus
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BIcons
import com.barbely.app.ui.theme.BRadius
import com.barbely.app.ui.theme.BType

/** Círculo con las iniciales del nombre (no hay fotos de perfil en esta versión). */
@Composable
fun Avatar(name: String, size: Int = 48) {
    val parts = name.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
    val initials = when {
        parts.isEmpty() -> "?"
        parts.size == 1 -> parts[0].take(2).uppercase()
        else -> (parts[0].take(1) + parts[1].take(1)).uppercase()
    }
    Box(
        modifier = Modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(BColors.surfaceElevated, CircleShape)
            .border(1.dp, BColors.border, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        BText(
            text = initials,
            style = BType.bodyMedium.copy(fontSize = (size * 0.38f).sp),
            color = BColors.gold,
        )
    }
}

/** Etiqueta de color según el estado de la cita. */
@Composable
fun StatusBadge(status: AppointmentStatus) {
    val color = when (status) {
        AppointmentStatus.PENDIENTE -> BColors.warning
        AppointmentStatus.CONFIRMADA -> BColors.info
        AppointmentStatus.COMPLETADA -> BColors.success
        AppointmentStatus.CANCELADA -> BColors.danger
    }
    val background = when (status) {
        AppointmentStatus.PENDIENTE -> BColors.warningBg
        AppointmentStatus.CONFIRMADA -> BColors.infoBg
        AppointmentStatus.COMPLETADA -> BColors.successBg
        AppointmentStatus.CANCELADA -> BColors.dangerBg
    }
    Row(
        modifier = Modifier
            .background(background, RoundedCornerShape(BRadius.pill))
            .padding(horizontal = 12.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(modifier = Modifier.size(6.dp).background(color, CircleShape))
        BText(status.label, BType.captionMedium, color)
    }
}

/** Estado vacío con ícono, título, descripción y acción opcional. */
@Composable
fun EmptyState(
    icon: Int,
    title: String,
    description: String? = null,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(
            modifier = Modifier
                .padding(bottom = 12.dp)
                .size(64.dp)
                .background(BColors.surface, CircleShape)
                .border(1.dp, BColors.border, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            BIcon(icon, 30.dp, BColors.gold)
        }
        BText(title, BType.h3, BColors.textPrimary, textAlign = TextAlign.Center)
        if (description != null) {
            BText(
                description, BType.body, BColors.textSecondary,
                Modifier.widthIn(max = 280.dp), textAlign = TextAlign.Center,
            )
        }
        if (actionLabel != null && onAction != null) {
            Box(modifier = Modifier.padding(top = 16.dp)) {
                BButton(actionLabel, onAction, variant = ButtonVariant.Secondary, fullWidth = false)
            }
        }
    }
}

/** Estado de error. */
@Composable
fun ErrorState(
    title: String = "Algo salió mal",
    description: String = "No pudimos completar esta acción. Inténtalo de nuevo.",
    onRetry: (() -> Unit)? = null,
) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(
            modifier = Modifier
                .padding(bottom = 12.dp)
                .size(64.dp)
                .background(BColors.dangerBg, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            BIcon(BIcons.AlertCircle, 30.dp, BColors.danger)
        }
        BText(title, BType.h3, BColors.textPrimary, textAlign = TextAlign.Center)
        BText(
            description, BType.body, BColors.textSecondary,
            Modifier.widthIn(max = 280.dp), textAlign = TextAlign.Center,
        )
        if (onRetry != null) {
            Box(modifier = Modifier.padding(top = 16.dp)) {
                BButton("Reintentar", onRetry, variant = ButtonVariant.Secondary, fullWidth = false)
            }
        }
    }
}

/**
 * Hoja modal inferior con fondo oscurecido (equivale a ui/Modal.tsx).
 * Debe colocarse dentro de un contenedor que ocupe toda la pantalla.
 */
@Composable
fun BModal(
    visible: Boolean,
    onClose: () -> Unit,
    title: String? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    if (!visible) return
    BackHandler(onBack = onClose)
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BColors.overlay)
            .tappable(onClick = onClose),
        contentAlignment = Alignment.BottomCenter,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = BRadius.xl, topEnd = BRadius.xl))
                .background(BColors.backgroundElevated)
                .tappable { } // absorbe los toques para que no cierren el modal
                .navigationBarsPadding()
                .padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 32.dp),
        ) {
            Box(
                modifier = Modifier
                    .padding(bottom = 16.dp)
                    .size(width = 40.dp, height = 4.dp)
                    .background(BColors.border, RoundedCornerShape(2.dp))
                    .align(Alignment.CenterHorizontally),
            )
            if (title != null) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    BText(title, BType.h3, BColors.textPrimary)
                    Box(modifier = Modifier.tappable(onClick = onClose)) {
                        BIcon(BIcons.Close, 22.dp, BColors.textSecondary)
                    }
                }
            }
            content()
        }
    }
}
