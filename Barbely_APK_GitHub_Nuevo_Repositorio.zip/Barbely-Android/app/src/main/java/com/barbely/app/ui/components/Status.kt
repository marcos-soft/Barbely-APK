package com.barbely.app.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.barbely.app.R
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BIcons
import com.barbely.app.ui.theme.BRadius
import com.barbely.app.ui.theme.BType

/** Círculo de carga con un texto debajo (mientras llegan los datos de Firebase). */
@Composable
fun LoadingState(text: String = "Cargando…", modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxWidth().padding(vertical = 48.dp, horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        CircularProgressIndicator(
            modifier = Modifier.size(30.dp),
            color = BColors.gold,
            strokeWidth = 3.dp,
        )
        BText(text, BType.body, BColors.textSecondary, textAlign = TextAlign.Center)
    }
}

/** Pantalla de arranque: se muestra mientras Firebase confirma si ya había una sesión iniciada. */
@Composable
fun SplashScreen() {
    Box(
        modifier = Modifier.fillMaxSize().background(BColors.background),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            Image(
                painter = painterResource(id = R.drawable.logo_mark),
                contentDescription = null,
                modifier = Modifier.size(width = 78.dp, height = 56.dp),
                contentScale = ContentScale.Fit,
            )
            CircularProgressIndicator(
                modifier = Modifier.size(26.dp),
                color = BColors.gold,
                strokeWidth = 2.5.dp,
            )
        }
    }
}

/**
 * Aviso de que no se pudo hablar con Firebase (sin Internet, reglas sin publicar, cuenta desactivada...).
 * Se dibuja encima de cualquier pantalla.
 */
@Composable
fun SyncBanner(message: String, onRetry: () -> Unit, onDismiss: () -> Unit) {
    val shape = RoundedCornerShape(BRadius.md)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .shadow(8.dp, shape)
            .background(BColors.dangerBg, shape)
            .border(1.dp, BColors.danger, shape)
            .padding(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 6.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Row(
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            BIcon(BIcons.AlertCircle, 20.dp, BColors.danger)
            BText(message, BType.caption, BColors.textPrimary, Modifier.weight(1f))
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BText(
                text = "Ocultar",
                style = BType.captionMedium,
                color = BColors.textSecondary,
                modifier = Modifier.tappable(onClick = onDismiss).padding(horizontal = 12.dp, vertical = 10.dp),
            )
            BText(
                text = "Reintentar",
                style = BType.captionMedium,
                color = BColors.gold,
                modifier = Modifier.tappable(onClick = onRetry).padding(horizontal = 12.dp, vertical = 10.dp),
            )
        }
    }
}
