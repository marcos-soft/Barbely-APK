package com.barbely.app.ui.nav

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import com.barbely.app.state.AppState

/** Pantallas de la app (reemplazan a las rutas de expo-router). */
sealed interface Route {
    data object Welcome : Route
    data object Login : Route
    data object Register : Route
    data object ForgotPassword : Route

    /** Pantalla principal con pestañas; el contenido depende del rol del usuario. */
    data object Home : Route

    // Cliente
    data class ServiceDetail(val id: String) : Route
    data class BookingBarber(val serviceId: String) : Route
    data class BookingDate(val serviceId: String, val barberId: String) : Route
    data class BookingTime(val serviceId: String, val barberId: String, val fecha: String) : Route
    data class BookingConfirm(
        val serviceId: String,
        val barberId: String,
        val fecha: String,
        val hora: String,
    ) : Route
    data class ClientAppointment(val id: String) : Route

    // Barbero
    data class BarberAppointment(val id: String) : Route
    data object BarberAvailability : Route

    // Gerente
    data class ManagerAppointment(val id: String) : Route
    data class BarberForm(val id: String?) : Route
    data class ServiceForm(val id: String?) : Route
}

/** Pila de navegación sencilla. La base de la pila es Welcome o Home. */
class Navigator(start: Route) {
    val stack = mutableStateListOf<Route>(start)

    /** Pestaña seleccionada en la pantalla principal. */
    var homeTab by mutableIntStateOf(0)

    val current: Route
        get() = stack.last()

    val canPop: Boolean
        get() = stack.size > 1

    fun push(route: Route) {
        stack.add(route)
    }

    fun pop() {
        if (stack.size > 1) stack.removeAt(stack.lastIndex)
    }

    /** Reemplaza toda la pila por [route] (p. ej. al iniciar o cerrar sesión). */
    fun resetTo(route: Route, tab: Int = 0) {
        stack.clear()
        stack.add(route)
        homeTab = tab
    }
}

val LocalApp = staticCompositionLocalOf<AppState> { error("AppState no disponible") }
val LocalNav = staticCompositionLocalOf<Navigator> { error("Navigator no disponible") }
