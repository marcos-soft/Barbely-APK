package com.barbely.app.data

import java.util.UUID

/**
 * BARBELY — Modelos de datos (equivalentes a src/types/index.ts de la app original).
 * Reflejan las colecciones de Cloud Firestore:
 * usuarios, barberos, servicios, horarios, citas y bloqueos.
 */

enum class UserRole(val db: String) {
    CLIENTE("cliente"),
    BARBERO("barbero"),
    GERENTE("gerente");

    companion object {
        fun from(value: String?): UserRole = entries.firstOrNull { it.db == value } ?: CLIENTE
    }
}

enum class AppointmentStatus(val db: String, val label: String) {
    PENDIENTE("pendiente", "Pendiente"),
    CONFIRMADA("confirmada", "Confirmada"),
    COMPLETADA("completada", "Completada"),
    CANCELADA("cancelada", "Cancelada");

    companion object {
        fun from(value: String?): AppointmentStatus =
            entries.firstOrNull { it.db == value } ?: PENDIENTE
    }
}

data class User(
    val uid: String,
    val nombre: String,
    val email: String,
    val telefono: String?,
    val rol: UserRole,
    val activo: Boolean,
    val createdAt: String,
)

data class Barber(
    val id: String,
    val nombre: String,
    val descripcion: String?,
    val especialidad: String,
    val calificacionPromedio: Double?,
    val activo: Boolean,
    val createdAt: String,
    val email: String?,
)

data class Service(
    val id: String,
    val nombre: String,
    val descripcion: String?,
    val precio: Double,
    val duracion: Int, // minutos
    val activo: Boolean,
    val createdAt: String,
    /**
     * Foto de referencia del servicio (campo "imagen" en Firestore). Puede ser:
     *  - una imagen incrustada: "data:image/jpeg;base64,..." (la que se elige desde la galería),
     *  - un enlace "https://..." (por ejemplo, cargado a mano en la consola de Firebase),
     *  - null: se muestra una ilustración según el nombre del servicio.
     */
    val imagen: String? = null,
)

/** diaSemana: 0 = domingo, 1 = lunes ... 6 = sábado (igual que Date#getDay() en JS). */
data class Schedule(
    val id: String,
    val barberoId: String,
    val diaSemana: Int,
    val horaInicio: String, // "09:00"
    val horaFin: String, // "18:00"
    val activo: Boolean,
)

/** Bloque de horario tal como lo edita la pantalla (id == null significa "nuevo"). */
data class ScheduleDraft(
    val id: String?,
    val diaSemana: Int,
    val horaInicio: String,
    val horaFin: String,
)

data class Appointment(
    val id: String,
    val clienteId: String,
    val barberoId: String,
    val servicioId: String,
    val fecha: String, // "2026-09-25"
    val horaInicio: String, // "10:30"
    val horaFin: String, // "11:00"
    val precio: Double,
    val duracion: Int,
    val estado: AppointmentStatus,
    val createdAt: String,
    val clienteNombre: String?,
    val clienteTelefono: String?,
    // Datos resueltos para mostrar en la interfaz (no se guardan en la cita)
    val barbero: Barber? = null,
    val servicio: Service? = null,
)

/**
 * Horario ocupado (colección "bloqueos"). Cada cita ocupa celdas de 15 minutos; el documento tiene
 * un id fijo "barbero_fecha_HHmm", así dos clientes no pueden reservar la misma hora a la vez.
 */
data class Bloqueo(
    val id: String,
    val barberoId: String,
    val fecha: String,
    val hora: String, // inicio de la celda de 15 min, "10:15"
    val clienteId: String,
    val citaId: String,
)

data class TimeSlot(
    val horaInicio: String,
    val horaFin: String,
    val disponible: Boolean,
)

/** Error con mensaje listo para mostrar al usuario. */
class AppException(message: String) : Exception(message)

fun newId(): String = UUID.randomUUID().toString()
