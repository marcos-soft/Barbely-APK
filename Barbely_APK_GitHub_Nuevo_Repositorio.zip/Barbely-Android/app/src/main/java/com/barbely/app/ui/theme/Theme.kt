package com.barbely.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.barbely.app.R

/**
 * BARBELY — Paleta de colores (src/theme/colors.ts).
 * Base cálida (carbón/grafito) + dorado latón envejecido como acento.
 */
object BColors {
    // Fondos
    val background = Color(0xFF0E0C0B)
    val backgroundElevated = Color(0xFF151210)
    val surface = Color(0xFF1B1714)
    val surfaceElevated = Color(0xFF231E19)
    val surfacePressed = Color(0xFF2A241E)

    // Bordes y separadores
    val border = Color(0xFF2E2822)
    val borderSubtle = Color(0xFF211C18)

    // Acento — dorado latón envejecido
    val gold = Color(0xFFC6A664)
    val goldMuted = Color(0xFF8E7642)
    val goldPressed = Color(0xFFA98D54)
    val onGold = Color(0xFF191410)

    // Texto
    val textPrimary = Color(0xFFF5F0E8)
    val textSecondary = Color(0xFFA79E92)
    val textMuted = Color(0xFF6E655A)

    // Estado
    val success = Color(0xFF7FA37A)
    val successBg = Color(0xFF1B2419)
    val danger = Color(0xFFC1554B)
    val dangerPressed = Color(0xFFA8443B)
    val dangerBg = Color(0xFF251715)
    val warning = Color(0xFFD1A24A)
    val warningBg = Color(0xFF231C13)
    val info = Color(0xFF6E8FA3)
    val infoBg = Color(0xFF161D21)

    // Utilidades
    val white = Color(0xFFFFFFFF)
    val overlay = Color(0xB80A0807) // rgba(10, 8, 7, 0.72)
}

/** Radios de esquina. */
object BRadius {
    val sm = 10.dp // inputs, botones, chips
    val md = 16.dp // elementos intermedios
    val lg = 20.dp // tarjetas de contenido
    val xl = 28.dp // hojas modales
    val pill = 999.dp // badges, cápsulas
}

/** Tipografías: Fraunces para títulos, Manrope para todo lo funcional. */
val FrauncesFamily = FontFamily(
    Font(R.font.fraunces_600semibold, FontWeight.SemiBold),
)

val ManropeFamily = FontFamily(
    Font(R.font.manrope_400regular, FontWeight.Normal),
    Font(R.font.manrope_500medium, FontWeight.Medium),
    Font(R.font.manrope_600semibold, FontWeight.SemiBold),
)

/** Estilos de texto (src/theme/typography.ts). */
object BType {
    val display = TextStyle(
        fontFamily = FrauncesFamily, fontWeight = FontWeight.SemiBold,
        fontSize = 34.sp, lineHeight = 40.sp, letterSpacing = 0.2.sp,
    )
    val h1 = TextStyle(
        fontFamily = FrauncesFamily, fontWeight = FontWeight.SemiBold,
        fontSize = 28.sp, lineHeight = 34.sp, letterSpacing = 0.1.sp,
    )
    val h2 = TextStyle(
        fontFamily = FrauncesFamily, fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp, lineHeight = 28.sp, letterSpacing = 0.sp,
    )
    val h3 = TextStyle(
        fontFamily = ManropeFamily, fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp, lineHeight = 24.sp, letterSpacing = 0.sp,
    )
    val bodyLarge = TextStyle(
        fontFamily = ManropeFamily, fontWeight = FontWeight.Normal,
        fontSize = 17.sp, lineHeight = 25.sp, letterSpacing = 0.sp,
    )
    val body = TextStyle(
        fontFamily = ManropeFamily, fontWeight = FontWeight.Normal,
        fontSize = 15.sp, lineHeight = 22.sp, letterSpacing = 0.sp,
    )
    val bodyMedium = TextStyle(
        fontFamily = ManropeFamily, fontWeight = FontWeight.Medium,
        fontSize = 15.sp, lineHeight = 22.sp, letterSpacing = 0.sp,
    )
    val caption = TextStyle(
        fontFamily = ManropeFamily, fontWeight = FontWeight.Normal,
        fontSize = 13.sp, lineHeight = 18.sp, letterSpacing = 0.1.sp,
    )
    val captionMedium = TextStyle(
        fontFamily = ManropeFamily, fontWeight = FontWeight.Medium,
        fontSize = 13.sp, lineHeight = 18.sp, letterSpacing = 0.1.sp,
    )
    val button = TextStyle(
        fontFamily = ManropeFamily, fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp, lineHeight = 20.sp, letterSpacing = 0.2.sp,
    )
    val label = TextStyle(
        fontFamily = ManropeFamily, fontWeight = FontWeight.Medium,
        fontSize = 13.sp, lineHeight = 18.sp, letterSpacing = 0.15.sp,
    )
}

@Composable
fun BarbelyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = BColors.gold,
            onPrimary = BColors.onGold,
            background = BColors.background,
            onBackground = BColors.textPrimary,
            surface = BColors.surface,
            onSurface = BColors.textPrimary,
            error = BColors.danger,
        ),
        content = content,
    )
}
