package com.barbely.app.ui.screens.client

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.barbely.app.data.AppointmentStatus
import com.barbely.app.logic.formatFechaLarga
import com.barbely.app.logic.money
import com.barbely.app.logic.serviceArtFor
import com.barbely.app.ui.components.BButton
import com.barbely.app.ui.components.BHeader
import com.barbely.app.ui.components.BModal
import com.barbely.app.ui.components.BText
import com.barbely.app.ui.components.ButtonVariant
import com.barbely.app.ui.components.ErrorState
import com.barbely.app.ui.components.InfoCard
import com.barbely.app.ui.components.InfoRow
import com.barbely.app.ui.components.LoadingState
import com.barbely.app.ui.components.ServiceImage
import com.barbely.app.ui.components.StatusBadge
import com.barbely.app.ui.components.rememberActionRunner
import com.barbely.app.ui.nav.LocalApp
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BIcons
import com.barbely.app.ui.theme.BRadius
import com.barbely.app.ui.theme.BType

@Composable
fun ClientAppointmentScreen(appointmentId: String) {
    val app = LocalApp.current
    val appointment = app.appointment(appointmentId)
    var confirmVisible by remember { mutableStateOf(false) }
    var cancelError by remember { mutableStateOf<String?>(null) }
    val action = rememberActionRunner()

    if (appointment == null) {
        Column(modifier = Modifier.fillMaxSize().background(BColors.background)) {
            BHeader(title = "Cita")
            if (!app.dataReady) {
                LoadingState("Cargando cita…")
            } else {
                ErrorState(title = "Cita no encontrada")
            }
        }
        return
    }

    val canCancel = appointment.estado == AppointmentStatus.PENDIENTE ||
        appointment.estado == AppointmentStatus.CONFIRMADA

    fun cancel() {
        cancelError = null
        action.run(
            onError = {
                cancelError = it
                confirmVisible = false
            },
        ) {
            app.updateAppointmentStatus(appointment.id, AppointmentStatus.CANCELADA)
            confirmVisible = false
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(BColors.background)) {
        Column(modifier = Modifier.fillMaxSize().navigationBarsPadding()) {
            BHeader(title = "Detalle de la cita")
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    BText(
                        text = appointment.servicio?.nombre ?: "Servicio",
                        style = BType.h1,
                        color = BColors.textPrimary,
                        modifier = Modifier.weight(1f).padding(end = 12.dp),
                    )
                    StatusBadge(appointment.estado)
                }
                val service = appointment.servicio
                if (service != null) {
                    val photoShape = RoundedCornerShape(BRadius.lg)
                    ServiceImage(
                        source = service.imagen,
                        art = serviceArtFor(service.nombre, service.descripcion),
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 9f)
                            .clip(photoShape)
                            .border(1.dp, BColors.borderSubtle, photoShape),
                        maxSide = 640,
                        description = "Foto de referencia de ${service.nombre}",
                    )
                }
                InfoCard {
                    InfoRow(BIcons.Person, "Barbero", appointment.barbero?.nombre ?: "—")
                    InfoRow(BIcons.Calendar, "Fecha", formatFechaLarga(appointment.fecha))
                    InfoRow(BIcons.Time, "Hora", "${appointment.horaInicio} – ${appointment.horaFin}")
                    InfoRow(BIcons.Pricetag, "Precio", money(appointment.precio))
                }
                val problem = cancelError
                if (problem != null) {
                    BText(problem, BType.caption, BColors.danger)
                }
                if (canCancel) {
                    BButton(
                        label = "Cancelar cita",
                        onClick = {
                            cancelError = null
                            confirmVisible = true
                        },
                        modifier = Modifier.padding(top = 12.dp),
                        variant = ButtonVariant.Danger,
                    )
                }
            }
        }

        BModal(
            visible = confirmVisible,
            onClose = { if (!action.running) confirmVisible = false },
            title = "¿Cancelar esta cita?",
        ) {
            val barberName = appointment.barbero?.nombre ?: "el barbero"
            BText(
                text = "Se liberará tu horario con $barberName el ${formatFechaLarga(appointment.fecha)} " +
                    "a las ${appointment.horaInicio}.",
                style = BType.body,
                color = BColors.textSecondary,
                modifier = Modifier.padding(bottom = 20.dp),
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BButton(
                    label = "Volver",
                    onClick = { confirmVisible = false },
                    modifier = Modifier.weight(1f),
                    variant = ButtonVariant.Ghost,
                    fullWidth = false,
                    enabled = !action.running,
                )
                BButton(
                    label = "Sí, cancelar",
                    onClick = { cancel() },
                    modifier = Modifier.weight(1f),
                    variant = ButtonVariant.Danger,
                    fullWidth = false,
                    loading = action.running,
                )
            }
        }
    }
}
