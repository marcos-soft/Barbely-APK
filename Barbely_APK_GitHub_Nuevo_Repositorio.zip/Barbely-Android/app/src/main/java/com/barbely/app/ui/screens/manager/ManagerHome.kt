package com.barbely.app.ui.screens.manager

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.barbely.app.data.AppointmentStatus
import com.barbely.app.logic.moneyRounded
import com.barbely.app.logic.todayISO
import com.barbely.app.ui.components.AppointmentCard
import com.barbely.app.ui.components.Avatar
import com.barbely.app.ui.components.BButton
import com.barbely.app.ui.components.BIcon
import com.barbely.app.ui.components.BInput
import com.barbely.app.ui.components.BText
import com.barbely.app.ui.components.BarberCard
import com.barbely.app.ui.components.BottomTabBar
import com.barbely.app.ui.components.ButtonVariant
import com.barbely.app.ui.components.EmptyState
import com.barbely.app.ui.components.FilterChip
import com.barbely.app.ui.components.LoadingState
import com.barbely.app.ui.components.ScheduleEditor
import com.barbely.app.ui.components.ServiceCard
import com.barbely.app.ui.components.StatCard
import com.barbely.app.ui.components.TabItem
import com.barbely.app.ui.components.TabTitle
import com.barbely.app.ui.components.rememberActionRunner
import com.barbely.app.ui.components.tappable
import com.barbely.app.ui.nav.LocalApp
import com.barbely.app.ui.nav.LocalNav
import com.barbely.app.ui.nav.Route
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BIcons
import com.barbely.app.ui.theme.BRadius
import com.barbely.app.ui.theme.BType
import kotlinx.coroutines.delay

/** Pantalla principal del gerente: Dashboard, Citas, Gestión, Horarios y Perfil. */
@Composable
fun ManagerHome() {
    val nav = LocalNav.current
    val tabs = remember {
        listOf(
            TabItem("Dashboard", BIcons.Grid),
            TabItem("Citas", BIcons.Calendar),
            TabItem("Gestión", BIcons.Briefcase),
            TabItem("Horarios", BIcons.Time),
            TabItem("Perfil", BIcons.Person),
        )
    }
    Column(modifier = Modifier.fillMaxSize().background(BColors.background).imePadding()) {
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (nav.homeTab) {
                0 -> ManagerDashboardTab()
                1 -> ManagerAppointmentsTab()
                2 -> ManagementTab()
                3 -> ManagerSchedulesTab()
                else -> ManagerProfileTab()
            }
        }
        BottomTabBar(items = tabs, selected = nav.homeTab, onSelect = { nav.homeTab = it })
    }
}

@Composable
private fun ManagerDashboardTab() {
    val app = LocalApp.current
    val today = todayISO()
    val todayAppointments = app.allAppointments()
        .filter { it.fecha == today && it.estado != AppointmentStatus.CANCELADA }
    val ingresoEstimado = todayAppointments.sumOf { it.precio }
    val activeBarbers = app.barbers.filter { it.activo }
    val activeServices = app.services.count { it.activo }
    val occupancy = activeBarbers
        .map { barber -> barber to todayAppointments.count { it.barberoId == barber.id } }
        .sortedByDescending { it.second }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(start = 24.dp, end = 24.dp, top = 32.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Column(
            modifier = Modifier.padding(bottom = 12.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            BText("Panel de administración", BType.h1, BColors.textPrimary)
            BText("Resumen de hoy en todas las sucursales", BType.body, BColors.textSecondary)
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Citas hoy", todayAppointments.size.toString(), Modifier.weight(1f))
            StatCard("Ingreso estimado", moneyRounded(ingresoEstimado), Modifier.weight(1f))
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Barberos activos", activeBarbers.size.toString(), Modifier.weight(1f))
            StatCard("Servicios activos", activeServices.toString(), Modifier.weight(1f))
        }

        Column(
            modifier = Modifier.padding(top = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            BText("Ocupación de hoy por barbero", BType.h3, BColors.textPrimary)
            if (!app.dataReady) LoadingState("Cargando datos…")
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                for ((barber, count) in occupancy) {
                    val shape = RoundedCornerShape(BRadius.md)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BColors.surface, shape)
                            .border(1.dp, BColors.borderSubtle, shape)
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        BText(barber.nombre, BType.bodyMedium, BColors.textPrimary, Modifier.weight(1f))
                        Box(
                            modifier = Modifier
                                .widthIn(min = 28.dp)
                                .heightIn(min = 28.dp)
                                .background(BColors.backgroundElevated, RoundedCornerShape(14.dp))
                                .padding(horizontal = 8.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            BText(count.toString(), BType.captionMedium, BColors.gold)
                        }
                    }
                }
            }
        }
    }
}

private data class StatusOption(val status: AppointmentStatus?, val label: String)

private val STATUS_FILTERS = listOf(
    StatusOption(null, "Todas"),
    StatusOption(AppointmentStatus.PENDIENTE, "Pendientes"),
    StatusOption(AppointmentStatus.CONFIRMADA, "Confirmadas"),
    StatusOption(AppointmentStatus.COMPLETADA, "Completadas"),
    StatusOption(AppointmentStatus.CANCELADA, "Canceladas"),
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ManagerAppointmentsTab() {
    val app = LocalApp.current
    val nav = LocalNav.current
    var statusFilter by remember { mutableStateOf<AppointmentStatus?>(null) }
    var barberFilter by remember { mutableStateOf<String?>(null) }

    val filtered = app.allAppointments()
        .filter { statusFilter == null || it.estado == statusFilter }
        .filter { barberFilter == null || it.barberoId == barberFilter }

    Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        TabTitle("Citas", bottomPadding = 12.dp)
        FlowRow(
            modifier = Modifier.padding(start = 24.dp, end = 24.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            for (option in STATUS_FILTERS) {
                FilterChip(
                    label = option.label,
                    active = statusFilter == option.status,
                    onClick = { statusFilter = option.status },
                )
            }
        }
        FlowRow(
            modifier = Modifier.padding(start = 24.dp, end = 24.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FilterChip(
                label = "Todos los barberos",
                active = barberFilter == null,
                onClick = { barberFilter = null },
            )
            for (barber in app.barbers) {
                FilterChip(
                    label = barber.nombre.trim().split(" ").first(),
                    active = barberFilter == barber.id,
                    onClick = { barberFilter = barber.id },
                )
            }
        }
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 24.dp, end = 24.dp, top = 12.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (!app.dataReady) {
                item { LoadingState("Cargando citas…") }
            } else if (filtered.isEmpty()) {
                item { EmptyState(icon = BIcons.Calendar, title = "No hay citas en este filtro") }
            } else {
                items(filtered, key = { it.id }) { appointment ->
                    AppointmentCard(
                        appointment = appointment,
                        subtitle = "${appointment.barbero?.nombre ?: "—"} · ${appointment.clienteNombre ?: "—"}",
                        onClick = { nav.push(Route.ManagerAppointment(appointment.id)) },
                    )
                }
            }
        }
    }
}

@Composable
private fun ManagementTab() {
    val app = LocalApp.current
    val nav = LocalNav.current
    var tab by remember { mutableStateOf(0) } // 0 = barberos, 1 = servicios
    val barbersTab = tab == 0
    val toggle = rememberActionRunner()
    var toggleError by remember { mutableStateOf<String?>(null) }

    Box(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        Column(modifier = Modifier.fillMaxSize()) {
            TabTitle("Gestión", bottomPadding = 12.dp)

            val outer = RoundedCornerShape(BRadius.md)
            val inner = RoundedCornerShape(BRadius.sm)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 24.dp, end = 24.dp, bottom = 16.dp)
                    .background(BColors.surface, outer)
                    .border(1.dp, BColors.borderSubtle, outer)
                    .padding(4.dp),
            ) {
                val labels = listOf("Barberos", "Servicios")
                for (index in labels.indices) {
                    val active = tab == index
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(if (active) BColors.gold else Color.Transparent, inner)
                            .tappable { tab = index }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        BText(
                            text = labels[index],
                            style = BType.captionMedium,
                            color = if (active) BColors.onGold else BColors.textSecondary,
                        )
                    }
                }
            }

            val problem = toggleError
            if (problem != null) {
                BText(
                    text = problem,
                    style = BType.caption,
                    color = BColors.danger,
                    modifier = Modifier.padding(start = 24.dp, end = 24.dp, bottom = 12.dp),
                )
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 24.dp, end = 24.dp, bottom = 110.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                if (!app.dataReady) {
                    item { LoadingState(if (barbersTab) "Cargando barberos…" else "Cargando servicios…") }
                } else if (barbersTab) {
                    if (app.barbers.isEmpty()) {
                        item { EmptyState(icon = BIcons.People, title = "Sin barberos todavía") }
                    } else {
                        items(app.barbers, key = { it.id }) { barber ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                Box(modifier = Modifier.weight(1f)) {
                                    BarberCard(
                                        barber = barber,
                                        onClick = { nav.push(Route.BarberForm(barber.id)) },
                                    )
                                }
                                VisibilityButton(
                                    active = barber.activo,
                                    enabled = !toggle.running,
                                    onClick = {
                                        toggleError = null
                                        toggle.run(onError = { toggleError = it }) {
                                            app.setBarberActive(barber.id, !barber.activo)
                                        }
                                    },
                                )
                            }
                        }
                    }
                } else {
                    if (app.services.isEmpty()) {
                        item { EmptyState(icon = BIcons.Cut, title = "Sin servicios todavía") }
                    } else {
                        items(app.services, key = { it.id }) { service ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                Box(modifier = Modifier.weight(1f)) {
                                    ServiceCard(
                                        service = service,
                                        onClick = { nav.push(Route.ServiceForm(service.id)) },
                                    )
                                }
                                VisibilityButton(
                                    active = service.activo,
                                    enabled = !toggle.running,
                                    onClick = {
                                        toggleError = null
                                        toggle.run(onError = { toggleError = it }) {
                                            app.setServiceActive(service.id, !service.activo)
                                        }
                                    },
                                )
                            }
                        }
                    }
                }
            }
        }

        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(start = 24.dp, end = 24.dp, bottom = 24.dp),
        ) {
            BButton(
                label = if (barbersTab) "Nuevo barbero" else "Nuevo servicio",
                onClick = {
                    nav.push(if (barbersTab) Route.BarberForm(null) else Route.ServiceForm(null))
                },
                icon = BIcons.Add,
            )
        }
    }
}

@Composable
private fun VisibilityButton(active: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .alpha(if (enabled) 1f else 0.45f)
            .background(BColors.surface, CircleShape)
            .border(1.dp, BColors.borderSubtle, CircleShape)
            .tappable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        BIcon(
            icon = if (active) BIcons.Eye else BIcons.EyeOff,
            size = 18.dp,
            tint = if (active) BColors.textSecondary else BColors.danger,
        )
    }
}

@Composable
private fun ManagerSchedulesTab() {
    val app = LocalApp.current
    val barbers = app.barbers.filter { it.activo }
    var selectedId by remember { mutableStateOf<String?>(null) }
    val effectiveId = selectedId ?: barbers.firstOrNull()?.id

    Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        TabTitle("Horarios", bottomPadding = 12.dp)
        if (!app.dataReady) {
            LoadingState("Cargando barberos…")
        } else if (barbers.isEmpty()) {
            EmptyState(
                icon = BIcons.People,
                title = "No hay barberos activos",
                description = "Activa un barbero para editar su horario.",
            )
        } else {
            Row(
                modifier = Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(start = 24.dp, end = 24.dp, bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                for (barber in barbers) {
                    FilterChip(
                        label = barber.nombre,
                        active = effectiveId == barber.id,
                        onClick = { selectedId = barber.id },
                        verticalPadding = 12.dp,
                    )
                }
            }
            if (effectiveId != null) {
                // key() reinicia el editor al cambiar de barbero.
                key(effectiveId) {
                    ScheduleEditor(barberoId = effectiveId)
                }
            }
        }
    }
}

@Composable
private fun ManagerProfileTab() {
    val app = LocalApp.current
    val nav = LocalNav.current
    val user = app.user
    var nombre by remember { mutableStateOf(user?.nombre ?: "Gerente") }
    var telefono by remember { mutableStateOf(user?.telefono ?: "") }
    var saved by remember { mutableStateOf(false) }
    var nameError by remember { mutableStateOf<String?>(null) }
    var saveError by remember { mutableStateOf<String?>(null) }
    val saveAction = rememberActionRunner()

    LaunchedEffect(saved) {
        if (saved) {
            delay(1800)
            saved = false
        }
    }

    fun save() {
        if (nombre.trim().isEmpty()) {
            nameError = "El nombre no puede estar vacío."
            return
        }
        nameError = null
        saveError = null
        saveAction.run(onError = { saveError = it }) {
            app.updateProfile(nombre.trim(), telefono.trim().ifEmpty { null })
            saved = true
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(start = 24.dp, end = 24.dp, top = 24.dp, bottom = 56.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Avatar(name = nombre, size = 72)
            BText(nombre, BType.h2, BColors.textPrimary, Modifier.padding(top = 12.dp))
            BText(user?.email ?: "gerente@barbely.com", BType.body, BColors.textSecondary)
        }

        Column {
            BInput(
                value = nombre,
                onValueChange = { nombre = it },
                label = "Nombre completo",
                leftIcon = BIcons.Person,
                error = nameError,
            )
            BInput(
                value = telefono,
                onValueChange = { telefono = it },
                label = "Teléfono",
                placeholder = "Opcional",
                leftIcon = BIcons.Call,
                keyboardType = KeyboardType.Phone,
            )
            val problem = saveError
            if (problem != null) {
                BText(problem, BType.caption, BColors.danger, Modifier.padding(bottom = 8.dp))
            }
            BButton(
                label = if (saved) "Guardado ✓" else "Guardar cambios",
                onClick = { save() },
                variant = ButtonVariant.Secondary,
                loading = saveAction.running,
            )
        }

        BButton(
            label = "Cerrar sesión",
            onClick = {
                app.signOut()
                nav.resetTo(Route.Welcome)
            },
            variant = ButtonVariant.Ghost,
        )
    }
}
