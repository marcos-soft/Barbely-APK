package com.barbely.app.ui.screens.client

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.barbely.app.logic.formatFechaCorta
import com.barbely.app.logic.formatFechaLarga
import com.barbely.app.logic.money
import com.barbely.app.logic.serviceArtFor
import com.barbely.app.logic.todayISO
import com.barbely.app.ui.components.BButton
import com.barbely.app.ui.components.BHeader
import com.barbely.app.ui.components.BText
import com.barbely.app.ui.components.BarberCard
import com.barbely.app.ui.components.DateSelector
import com.barbely.app.ui.components.EmptyState
import com.barbely.app.ui.components.InfoCard
import com.barbely.app.ui.components.InfoRow
import com.barbely.app.ui.components.LoadingState
import com.barbely.app.ui.components.ScreenFooter
import com.barbely.app.ui.components.ServiceImage
import com.barbely.app.ui.components.TimeSelector
import com.barbely.app.ui.components.rememberActionRunner
import com.barbely.app.ui.nav.LocalApp
import com.barbely.app.ui.nav.LocalNav
import com.barbely.app.ui.nav.Route
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BIcons
import com.barbely.app.ui.theme.BRadius
import com.barbely.app.ui.theme.BType

@Composable
private fun StepLabel(text: String) {
    BText(
        text = text,
        style = BType.captionMedium,
        color = BColors.gold,
        modifier = Modifier.padding(start = 24.dp, end = 24.dp, bottom = 12.dp),
    )
}

/** Paso 1 de 3: elegir barbero. */
@Composable
fun BookingBarberScreen(serviceId: String) {
    val app = LocalApp.current
    val nav = LocalNav.current
    val service = app.service(serviceId)
    val barbers = app.activeBarbers()
    var selectedId by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier.fillMaxSize().background(BColors.background).navigationBarsPadding(),
    ) {
        BHeader(title = "Elige tu barbero")
        StepLabel("Paso 1 de 3" + if (service != null) " · ${service.nombre}" else "")
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(start = 24.dp, end = 24.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (!app.dataReady) {
                item { LoadingState("Cargando barberos…") }
            } else if (barbers.isEmpty()) {
                item { EmptyState(icon = BIcons.People, title = "No hay barberos disponibles") }
            } else {
                items(barbers, key = { it.id }) { barber ->
                    BarberCard(
                        barber = barber,
                        selected = barber.id == selectedId,
                        onClick = { selectedId = barber.id },
                    )
                }
            }
        }
        ScreenFooter {
            BButton(
                label = "Continuar",
                enabled = selectedId != null,
                onClick = {
                    val chosen = selectedId
                    if (chosen != null) nav.push(Route.BookingDate(serviceId, chosen))
                },
            )
        }
    }
}

/** Paso 2 de 3: elegir fecha. */
@Composable
fun BookingDateScreen(serviceId: String, barberId: String) {
    val app = LocalApp.current
    val nav = LocalNav.current
    val barber = app.barber(barberId)
    var selectedDate by remember { mutableStateOf(todayISO()) }

    Column(
        modifier = Modifier.fillMaxSize().background(BColors.background).navigationBarsPadding(),
    ) {
        BHeader(title = "Elige la fecha")
        StepLabel("Paso 2 de 3" + if (barber != null) " · ${barber.nombre}" else "")
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(start = 24.dp, end = 24.dp, top = 12.dp),
        ) {
            DateSelector(selectedDate = selectedDate, onSelect = { selectedDate = it })
        }
        ScreenFooter {
            BButton(
                label = "Continuar",
                onClick = { nav.push(Route.BookingTime(serviceId, barberId, selectedDate)) },
            )
        }
    }
}

/** Paso 3 de 3: elegir hora (solo franjas libres). */
@Composable
fun BookingTimeScreen(serviceId: String, barberId: String, fecha: String) {
    val app = LocalApp.current
    val nav = LocalNav.current
    val service = app.service(serviceId)
    val duracion = service?.duracion ?: 30
    var selectedTime by remember { mutableStateOf<String?>(null) }
    val slots = remember(app.dataVersion, barberId, fecha, duracion) {
        app.slotsFor(barberId, fecha, duracion)
    }
    val hasAvailable = slots.any { it.disponible }

    Column(
        modifier = Modifier.fillMaxSize().background(BColors.background).navigationBarsPadding(),
    ) {
        BHeader(title = "Elige la hora")
        StepLabel("Paso 3 de 3 · " + formatFechaCorta(fecha))
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(start = 24.dp, end = 24.dp, top = 12.dp),
        ) {
            if (!app.dataReady) {
                LoadingState("Buscando horarios…")
            } else if (slots.isEmpty()) {
                EmptyState(
                    icon = BIcons.Time,
                    title = "Sin horarios este día",
                    description = "El barbero no atiende este día. Elige otra fecha.",
                )
            } else if (!hasAvailable) {
                EmptyState(
                    icon = BIcons.Time,
                    title = "Sin horarios disponibles",
                    description = "Todas las franjas de este día ya están ocupadas o pasaron. Elige otra fecha.",
                )
            } else {
                TimeSelector(slots = slots, selectedTime = selectedTime, onSelect = { selectedTime = it })
            }
        }
        ScreenFooter {
            BButton(
                label = "Continuar",
                enabled = selectedTime != null,
                onClick = {
                    val hora = selectedTime
                    if (hora != null) nav.push(Route.BookingConfirm(serviceId, barberId, fecha, hora))
                },
            )
        }
    }
}

/** Resumen y confirmación de la reserva. */
@Composable
fun BookingConfirmScreen(serviceId: String, barberId: String, fecha: String, hora: String) {
    val app = LocalApp.current
    val nav = LocalNav.current
    val user = app.user
    val service = app.service(serviceId)
    val barber = app.barber(barberId)
    var error by remember { mutableStateOf<String?>(null) }
    val action = rememberActionRunner()

    if (service == null || barber == null || user == null) {
        Column(modifier = Modifier.fillMaxSize().background(BColors.background)) {
            BHeader(title = "Confirmar cita")
            if (!app.dataReady) {
                LoadingState("Cargando datos de la reserva…")
            } else {
                BText(
                    text = "Faltan datos de la reserva. Vuelve a intentarlo.",
                    style = BType.caption,
                    color = BColors.danger,
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    textAlign = TextAlign.Center,
                )
            }
        }
        return
    }

    fun confirm() {
        error = null
        action.run(onError = { error = it }) {
            app.createAppointment(barber.id, service.id, fecha, hora)
            // Vuelve a la pantalla principal, pestaña "Mis citas".
            nav.resetTo(Route.Home, tab = 2)
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().background(BColors.background).navigationBarsPadding(),
    ) {
        BHeader(title = "Confirmar cita")
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
        ) {
            val photoShape = RoundedCornerShape(BRadius.lg)
            ServiceImage(
                source = service.imagen,
                art = serviceArtFor(service.nombre, service.descripcion),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .aspectRatio(16f / 9f)
                    .clip(photoShape)
                    .border(1.dp, BColors.borderSubtle, photoShape),
                maxSide = 640,
                description = "Foto de referencia de ${service.nombre}",
            )
            InfoCard {
                InfoRow(BIcons.Cut, "Servicio", service.nombre)
                InfoRow(BIcons.Person, "Barbero", barber.nombre)
                InfoRow(BIcons.Calendar, "Fecha", formatFechaLarga(fecha))
                InfoRow(BIcons.Time, "Hora", hora)
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(BColors.borderSubtle))
                InfoRow(BIcons.Pricetag, "Total", money(service.precio), emphasis = true)
            }
            val message = error
            if (message != null) {
                BText(
                    text = message,
                    style = BType.caption,
                    color = BColors.danger,
                    modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                    textAlign = TextAlign.Center,
                )
            }
        }
        ScreenFooter {
            BButton(label = "Confirmar reserva", onClick = { confirm() }, loading = action.running)
        }
    }
}
