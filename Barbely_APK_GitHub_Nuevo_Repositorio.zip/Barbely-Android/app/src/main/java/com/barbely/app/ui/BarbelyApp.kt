package com.barbely.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.barbely.app.data.UserRole
import com.barbely.app.state.AppState
import com.barbely.app.ui.nav.LocalApp
import com.barbely.app.ui.nav.LocalNav
import com.barbely.app.ui.nav.Navigator
import com.barbely.app.ui.nav.Route
import com.barbely.app.ui.screens.auth.ForgotPasswordScreen
import com.barbely.app.ui.screens.auth.LoginScreen
import com.barbely.app.ui.screens.auth.RegisterScreen
import com.barbely.app.ui.screens.auth.WelcomeScreen
import com.barbely.app.ui.screens.barber.BarberAppointmentScreen
import com.barbely.app.ui.screens.barber.BarberAvailabilityScreen
import com.barbely.app.ui.screens.barber.BarberHome
import com.barbely.app.ui.screens.client.BookingBarberScreen
import com.barbely.app.ui.screens.client.BookingConfirmScreen
import com.barbely.app.ui.screens.client.BookingDateScreen
import com.barbely.app.ui.screens.client.BookingTimeScreen
import com.barbely.app.ui.screens.client.ClientAppointmentScreen
import com.barbely.app.ui.screens.client.ClientHome
import com.barbely.app.ui.screens.client.ServiceDetailScreen
import com.barbely.app.ui.screens.manager.BarberFormScreen
import com.barbely.app.ui.screens.manager.ManagerAppointmentScreen
import com.barbely.app.ui.screens.manager.ManagerHome
import com.barbely.app.ui.screens.manager.ServiceFormScreen
import com.barbely.app.ui.components.SplashScreen
import com.barbely.app.ui.components.SyncBanner
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BarbelyTheme

/** Raíz de la app: tema, estado compartido, botón "atrás" y enrutado de pantallas. */
@Composable
fun BarbelyApp(appState: AppState, navigator: Navigator) {
    BarbelyTheme {
        CompositionLocalProvider(
            LocalApp provides appState,
            LocalNav provides navigator,
        ) {
            val onHomeTab = navigator.current == Route.Home && navigator.homeTab != 0
            BackHandler(enabled = navigator.canPop || onHomeTab) {
                if (navigator.canPop) navigator.pop() else navigator.homeTab = 0
            }

            // Mantiene la navegación coherente con la sesión: al confirmarse una sesión guardada (o al
            // iniciar sesión) se pasa a Inicio; si la sesión se pierde (cuenta desactivada, sesión
            // vencida, eliminada desde otro lugar) se vuelve a Bienvenida.
            val signedInUid = appState.user?.uid
            val authLoading = appState.authLoading
            LaunchedEffect(signedInUid, authLoading) {
                if (authLoading) return@LaunchedEffect
                if (signedInUid != null && navigator.current in AUTH_ROUTES) {
                    navigator.resetTo(Route.Home)
                } else if (signedInUid == null && navigator.current !in AUTH_ROUTES) {
                    navigator.resetTo(Route.Welcome)
                }
            }

            Box(modifier = Modifier.fillMaxSize().background(BColors.background)) {
                if (authLoading) {
                    SplashScreen()
                } else {
                    AppRoutes(appState, navigator)
                }
                val syncError = appState.syncError
                if (syncError != null) {
                    Box(modifier = Modifier.align(Alignment.TopCenter)) {
                        SyncBanner(
                            message = syncError,
                            onRetry = { appState.retrySync() },
                            onDismiss = { appState.dismissSyncError() },
                        )
                    }
                }
            }
        }
    }
}

/** Pantallas que se ven sin sesión iniciada. */
private val AUTH_ROUTES: Set<Route> = setOf(Route.Welcome, Route.Login, Route.Register, Route.ForgotPassword)

@Composable
private fun AppRoutes(app: AppState, nav: Navigator) {
    when (val route = nav.current) {
        Route.Welcome -> WelcomeScreen()
        Route.Login -> LoginScreen()
        Route.Register -> RegisterScreen()
        Route.ForgotPassword -> ForgotPasswordScreen()
        Route.Home -> HomeForRole(app)

        is Route.ServiceDetail -> ServiceDetailScreen(route.id)
        is Route.BookingBarber -> BookingBarberScreen(route.serviceId)
        is Route.BookingDate -> BookingDateScreen(route.serviceId, route.barberId)
        is Route.BookingTime -> BookingTimeScreen(route.serviceId, route.barberId, route.fecha)
        is Route.BookingConfirm ->
            BookingConfirmScreen(route.serviceId, route.barberId, route.fecha, route.hora)
        is Route.ClientAppointment -> ClientAppointmentScreen(route.id)

        is Route.BarberAppointment -> BarberAppointmentScreen(route.id)
        Route.BarberAvailability -> BarberAvailabilityScreen()

        is Route.ManagerAppointment -> ManagerAppointmentScreen(route.id)
        is Route.BarberForm -> BarberFormScreen(route.id)
        is Route.ServiceForm -> ServiceFormScreen(route.id)
    }
}

/** La pantalla principal depende del rol del usuario (cliente, barbero o gerente). */
@Composable
private fun HomeForRole(app: AppState) {
    when (app.user?.rol) {
        UserRole.CLIENTE -> ClientHome()
        UserRole.BARBERO -> BarberHome()
        UserRole.GERENTE -> ManagerHome()
        null -> WelcomeScreen()
    }
}
