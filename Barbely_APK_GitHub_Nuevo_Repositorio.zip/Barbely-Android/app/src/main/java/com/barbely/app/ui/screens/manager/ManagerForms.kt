package com.barbely.app.ui.screens.manager

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.barbely.app.data.Barber
import com.barbely.app.data.ImageProcessor
import com.barbely.app.data.Service
import com.barbely.app.logic.serviceArtFor
import com.barbely.app.ui.components.ActiveToggleRow
import com.barbely.app.ui.components.BButton
import com.barbely.app.ui.components.BHeader
import com.barbely.app.ui.components.BInput
import com.barbely.app.ui.components.BText
import com.barbely.app.ui.components.ButtonVariant
import com.barbely.app.ui.components.ErrorState
import com.barbely.app.ui.components.LoadingState
import com.barbely.app.ui.components.ReferencePill
import com.barbely.app.ui.components.ScreenFooter
import com.barbely.app.ui.components.ServiceImage
import com.barbely.app.ui.components.rememberActionRunner
import com.barbely.app.ui.components.tappable
import com.barbely.app.ui.nav.LocalApp
import com.barbely.app.ui.nav.LocalNav
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BIcons
import com.barbely.app.ui.theme.BRadius
import com.barbely.app.ui.theme.BType

/** Alta y edición de barberos (id == null crea uno nuevo). */
@Composable
fun BarberFormScreen(barberId: String?) {
    val app = LocalApp.current
    val existing = if (barberId != null) app.barber(barberId) else null

    if (barberId != null && existing == null) {
        Column(modifier = Modifier.fillMaxSize().background(BColors.background)) {
            BHeader(title = "Barbero")
            if (!app.dataReady) {
                LoadingState("Cargando barbero…")
            } else {
                ErrorState(title = "Barbero no encontrado", description = "Puede que ya no exista.")
            }
        }
        return
    }
    BarberFormContent(existing)
}

@Composable
private fun BarberFormContent(existing: Barber?) {
    val app = LocalApp.current
    val nav = LocalNav.current
    val isEditing = existing != null
    val action = rememberActionRunner()

    var nombre by remember { mutableStateOf(existing?.nombre ?: "") }
    var especialidad by remember { mutableStateOf(existing?.especialidad ?: "") }
    var descripcion by remember { mutableStateOf(existing?.descripcion ?: "") }
    var activo by remember { mutableStateOf(existing?.activo ?: true) }
    var email by remember { mutableStateOf(existing?.email ?: "") }
    var initialPassword by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    fun submit() {
        if (nombre.trim().isEmpty() || especialidad.trim().isEmpty()) {
            error = "Nombre y especialidad son obligatorios."
            return
        }
        if (!isEditing && (email.trim().isEmpty() || initialPassword.length < 6)) {
            error = "Para crear un barbero necesitas un correo y una contraseña de al menos 6 caracteres."
            return
        }
        error = null
        action.run(onError = { error = it }) {
            app.saveBarber(
                id = existing?.id,
                nombre = nombre.trim(),
                especialidad = especialidad.trim(),
                descripcion = descripcion.trim().ifEmpty { null },
                activo = activo,
                email = email.trim(),
                initialPassword = if (isEditing) null else initialPassword,
            )
            nav.pop()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BColors.background)
            .navigationBarsPadding()
            .imePadding(),
    ) {
        BHeader(title = if (isEditing) "Editar barbero" else "Nuevo barbero")
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
        ) {
            BInput(
                value = nombre,
                onValueChange = { nombre = it },
                label = "Nombre completo",
                leftIcon = BIcons.Person,
                capitalization = KeyboardCapitalization.Words,
            )
            BInput(
                value = especialidad,
                onValueChange = { especialidad = it },
                label = "Especialidad",
                leftIcon = BIcons.Cut,
            )
            BInput(
                value = email,
                onValueChange = { email = it },
                label = "Correo de acceso",
                leftIcon = BIcons.Mail,
                keyboardType = KeyboardType.Email,
                capitalization = KeyboardCapitalization.None,
            )
            if (isEditing) {
                BText(
                    text = "Cambiar este correo no cambia con cuál inicia sesión el barbero (eso se maneja en " +
                        "Firebase Authentication).",
                    style = BType.caption,
                    color = BColors.textMuted,
                    modifier = Modifier.padding(bottom = 16.dp),
                )
            } else {
                BInput(
                    value = initialPassword,
                    onValueChange = { initialPassword = it },
                    label = "Contraseña inicial",
                    leftIcon = BIcons.LockClosed,
                    secure = true,
                    keyboardType = KeyboardType.Password,
                    capitalization = KeyboardCapitalization.None,
                )
                BText(
                    text = "Se crea su cuenta en Firebase Authentication. Entrégale este correo y esta contraseña; " +
                        "después puede cambiarla con «¿Olvidaste tu contraseña?».",
                    style = BType.caption,
                    color = BColors.textMuted,
                    modifier = Modifier.padding(bottom = 16.dp),
                )
            }
            BInput(
                value = descripcion,
                onValueChange = { descripcion = it },
                label = "Descripción",
                placeholder = "Opcional",
                leftIcon = BIcons.DocumentText,
                multiline = true,
            )
            ActiveToggleRow(active = activo, onToggle = { activo = !activo })
            val message = error
            if (message != null) {
                BText(message, BType.caption, BColors.danger, Modifier.padding(top = 12.dp))
            }
        }
        ScreenFooter {
            BButton(
                label = if (isEditing) "Guardar cambios" else "Crear barbero",
                onClick = { submit() },
                loading = action.running,
            )
        }
    }
}

private fun plainNumber(value: Double): String =
    if (value % 1.0 == 0.0) value.toLong().toString() else value.toString()

/** Alta y edición de servicios (id == null crea uno nuevo), con su foto de referencia. */
@Composable
fun ServiceFormScreen(serviceId: String?) {
    val app = LocalApp.current
    val existing = if (serviceId != null) app.service(serviceId) else null

    if (serviceId != null && existing == null) {
        Column(modifier = Modifier.fillMaxSize().background(BColors.background)) {
            BHeader(title = "Servicio")
            if (!app.dataReady) {
                LoadingState("Cargando servicio…")
            } else {
                ErrorState(title = "Servicio no encontrado", description = "Puede que ya no exista.")
            }
        }
        return
    }
    ServiceFormContent(existing)
}

@Composable
private fun ServiceFormContent(existing: Service?) {
    val app = LocalApp.current
    val nav = LocalNav.current
    val context = LocalContext.current
    val isEditing = existing != null
    val saveAction = rememberActionRunner()
    val photoAction = rememberActionRunner()

    var nombre by remember { mutableStateOf(existing?.nombre ?: "") }
    var descripcion by remember { mutableStateOf(existing?.descripcion ?: "") }
    var precio by remember { mutableStateOf(if (existing != null) plainNumber(existing.precio) else "") }
    var duracion by remember { mutableStateOf(if (existing != null) existing.duracion.toString() else "") }
    var activo by remember { mutableStateOf(existing?.activo ?: true) }
    var imagen by remember { mutableStateOf(existing?.imagen) }
    var linkVisible by remember { mutableStateOf(false) }
    var link by remember { mutableStateOf("") }
    var photoError by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) {
            photoError = null
            photoAction.run(onError = { photoError = it }) {
                imagen = ImageProcessor.fromUri(context, uri)
            }
        }
    }

    fun downloadLink() {
        val url = link.trim()
        if (!url.startsWith("https://", ignoreCase = true)) {
            photoError = "Pega un enlace que empiece con https://"
            return
        }
        photoError = null
        photoAction.run(onError = { photoError = it }) {
            imagen = ImageProcessor.fromUrl(url)
            link = ""
            linkVisible = false
        }
    }

    fun submit() {
        val precioNum = precio.trim().replace(',', '.').toDoubleOrNull()
        val duracionNum = duracion.trim().toIntOrNull()
        if (nombre.trim().isEmpty()) {
            error = "El nombre es obligatorio."
            return
        }
        if (precioNum == null || !precioNum.isFinite() || precioNum <= 0.0) {
            error = "El precio debe ser un número mayor a cero."
            return
        }
        if (duracionNum == null || duracionNum <= 0) {
            error = "La duración debe ser un número entero de minutos mayor a cero."
            return
        }
        error = null
        saveAction.run(onError = { error = it }) {
            app.saveService(
                id = existing?.id,
                nombre = nombre.trim(),
                descripcion = descripcion.trim().ifEmpty { null },
                precio = precioNum,
                duracion = duracionNum,
                imagen = imagen,
                activo = activo,
            )
            nav.pop()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BColors.background)
            .navigationBarsPadding()
            .imePadding(),
    ) {
        BHeader(title = if (isEditing) "Editar servicio" else "Nuevo servicio")
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
        ) {
            // ---- Foto de referencia ----
            BText("Foto de referencia", BType.label, BColors.textSecondary, Modifier.padding(bottom = 8.dp))
            val photoShape = RoundedCornerShape(BRadius.lg)
            ServiceImage(
                source = imagen,
                art = serviceArtFor(nombre, descripcion),
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(4f / 3f)
                    .clip(photoShape)
                    .border(1.dp, BColors.borderSubtle, photoShape),
                maxSide = 800,
                description = "Foto de referencia del servicio",
                overlay = { isPhoto -> ReferencePill(isPhoto) },
            )
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                BButton(
                    label = if (imagen == null) "Elegir foto" else "Cambiar foto",
                    onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier.weight(1f),
                    variant = ButtonVariant.Secondary,
                    fullWidth = false,
                    loading = photoAction.running && !linkVisible,
                    enabled = !photoAction.running,
                )
                BButton(
                    label = "Pegar enlace",
                    onClick = { linkVisible = !linkVisible },
                    modifier = Modifier.weight(1f),
                    variant = ButtonVariant.Ghost,
                    fullWidth = false,
                    enabled = !photoAction.running,
                )
            }
            if (linkVisible) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    BInput(
                        value = link,
                        onValueChange = { link = it },
                        label = "Enlace de la foto",
                        placeholder = "https://…",
                        leftIcon = BIcons.DocumentText,
                        keyboardType = KeyboardType.Uri,
                        capitalization = KeyboardCapitalization.None,
                    )
                    BButton(
                        label = "Descargar y usar esta foto",
                        onClick = { downloadLink() },
                        variant = ButtonVariant.Secondary,
                        loading = photoAction.running && linkVisible,
                        enabled = link.isNotBlank(),
                    )
                }
            }
            if (imagen != null) {
                BText(
                    text = "Quitar foto (se mostrará la ilustración)",
                    style = BType.captionMedium,
                    color = BColors.danger,
                    modifier = Modifier
                        .padding(top = 6.dp)
                        .tappable(enabled = !photoAction.running) { imagen = null }
                        .padding(vertical = 6.dp),
                )
            }
            val photoProblem = photoError
            if (photoProblem != null) {
                BText(photoProblem, BType.caption, BColors.danger, Modifier.padding(top = 8.dp))
            }
            BText(
                text = "La foto se guarda en Firebase junto al servicio (se reduce sola a 800 px). " +
                    "Los clientes la ven en la lista de servicios y en su detalle.",
                style = BType.caption,
                color = BColors.textMuted,
                modifier = Modifier.padding(top = 8.dp, bottom = 20.dp),
            )

            // ---- Datos del servicio ----
            BInput(
                value = nombre,
                onValueChange = { nombre = it },
                label = "Nombre",
                leftIcon = BIcons.Cut,
            )
            BInput(
                value = descripcion,
                onValueChange = { descripcion = it },
                label = "Descripción",
                placeholder = "Opcional",
                leftIcon = BIcons.DocumentText,
                multiline = true,
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(modifier = Modifier.weight(1f)) {
                    BInput(
                        value = precio,
                        onValueChange = { precio = it },
                        label = "Precio (USD)",
                        placeholder = "8.00",
                        leftIcon = BIcons.Pricetag,
                        keyboardType = KeyboardType.Decimal,
                    )
                }
                Box(modifier = Modifier.weight(1f)) {
                    BInput(
                        value = duracion,
                        onValueChange = { duracion = it },
                        label = "Duración (min)",
                        placeholder = "30",
                        leftIcon = BIcons.Time,
                        keyboardType = KeyboardType.Number,
                    )
                }
            }
            ActiveToggleRow(active = activo, onToggle = { activo = !activo })
            val message = error
            if (message != null) {
                BText(message, BType.caption, BColors.danger, Modifier.padding(top = 12.dp))
            }
        }
        ScreenFooter {
            BButton(
                label = if (isEditing) "Guardar cambios" else "Crear servicio",
                onClick = { submit() },
                loading = saveAction.running,
                enabled = !photoAction.running,
            )
        }
    }
}
