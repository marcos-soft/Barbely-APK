package com.barbely.app.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.barbely.app.logic.blockCells
import com.google.firebase.FirebaseApp
import com.google.firebase.Timestamp
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.Transaction
import java.time.Instant
import java.time.temporal.ChronoUnit
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout

/**
 * Implementación real: Firebase Authentication + Cloud Firestore, el MISMO proyecto y las mismas
 * colecciones que usaba la app original (usuarios, barberos, servicios, horarios, citas, bloqueos).
 *
 * Las reglas de seguridad que deben estar publicadas en Firestore son las de firebase/firestore.rules.
 */
class FirebaseBackend(context: Context) : Backend {

    private val context: Context = context.applicationContext
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()

    init {
        // Los correos de Firebase (recuperar contraseña) salen en español.
        auth.setLanguageCode("es")
    }

    // ------------------------------------------------------------------
    // Autenticación
    // ------------------------------------------------------------------

    override val currentUid: String?
        get() = auth.currentUser?.uid

    override fun listenAuth(onChange: (uid: String?) -> Unit): Stop {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            onChange(firebaseAuth.currentUser?.uid)
        }
        auth.addAuthStateListener(listener)
        return { auth.removeAuthStateListener(listener) }
    }

    override suspend fun signIn(email: String, password: String): String = FirebaseErrors.guard {
        val result = auth.signInWithEmailAndPassword(email, password).await()
        result.user?.uid ?: throw AppException("No se pudo iniciar sesión. Inténtalo de nuevo.")
    }

    override suspend fun signUp(nombre: String, email: String, password: String): String = FirebaseErrors.guard {
        val result = auth.createUserWithEmailAndPassword(email, password).await()
        val created = result.user ?: throw AppException("No se pudo crear la cuenta. Inténtalo de nuevo.")
        try {
            created.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(nombre).build()).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // El nombre también se guarda en Firestore; no es crítico si esto falla.
        }
        created.uid
    }

    override suspend fun sendPasswordReset(email: String) {
        FirebaseErrors.guard { auth.sendPasswordResetEmail(email).await() }
    }

    override fun signOut() {
        auth.signOut()
    }

    override suspend fun reauthenticate(password: String) {
        FirebaseErrors.guard {
            val current = auth.currentUser ?: throw AppException("No hay una sesión activa.")
            val email = current.email ?: throw AppException("Tu cuenta no tiene un correo asociado.")
            try {
                current.reauthenticate(EmailAuthProvider.getCredential(email, password)).await()
            } catch (e: FirebaseAuthException) {
                if (e.errorCode == "ERROR_WRONG_PASSWORD" || e.errorCode == "ERROR_INVALID_CREDENTIAL" ||
                    e.errorCode == "ERROR_INVALID_LOGIN_CREDENTIALS"
                ) {
                    throw AppException("La contraseña no es correcta.")
                }
                throw e
            }
        }
    }

    override suspend fun deleteAuthAccount() {
        FirebaseErrors.guard { auth.currentUser?.delete()?.await() }
    }

    override suspend fun createStaffAccount(email: String, password: String): String = write {
        // Una segunda instancia de Firebase permite crear la cuenta del barbero sin cerrar la sesión del gerente.
        val secondary = secondaryApp()
        val secondaryAuth = FirebaseAuth.getInstance(secondary)
        try {
            val uid = try {
                secondaryAuth.createUserWithEmailAndPassword(email, password).await().user?.uid
            } catch (e: FirebaseAuthUserCollisionException) {
                // ¿Quedó huérfana de un intento anterior (cuenta creada pero sin perfil)? Si la contraseña
                // coincide y no tiene perfil en Firestore, se reutiliza; si no, el correo ya está en uso.
                val existing = try {
                    secondaryAuth.signInWithEmailAndPassword(email, password).await().user?.uid
                } catch (inner: CancellationException) {
                    throw inner
                } catch (inner: Exception) {
                    null
                }
                if (existing == null || userProfileExists(existing)) throw e
                existing
            }
            uid ?: throw AppException("No se pudo crear la cuenta de acceso del barbero.")
        } finally {
            secondaryAuth.signOut()
        }
    }

    private fun secondaryApp(): FirebaseApp =
        FirebaseApp.getApps(context).firstOrNull { it.name == SECONDARY_APP_NAME }
            ?: FirebaseApp.initializeApp(context, FirebaseApp.getInstance().options, SECONDARY_APP_NAME)

    private suspend fun userProfileExists(uid: String): Boolean =
        db.collection("usuarios").document(uid).get().await().exists()

    // ------------------------------------------------------------------
    // Perfil de usuario
    // ------------------------------------------------------------------

    override suspend fun loadUser(uid: String): User = FirebaseErrors.guard {
        val ref = db.collection("usuarios").document(uid)
        val snapshot = ref.get().await()
        val authUser = auth.currentUser
        if (snapshot.exists()) {
            userFrom(snapshot, authUser)
        } else {
            // Cuenta de acceso sin perfil: se crea como cliente (igual que la app original).
            val nombre = authUser?.displayName?.takeIf { it.isNotBlank() }
                ?: authUser?.email?.substringBefore('@')?.takeIf { it.isNotBlank() }
                ?: "Usuario"
            val fallback = User(
                uid = uid,
                nombre = nombre,
                email = authUser?.email.orEmpty(),
                telefono = null,
                rol = UserRole.CLIENTE,
                activo = true,
                createdAt = isoNow(),
            )
            ref.set(userMap(fallback)).await()
            fallback
        }
    }

    override suspend fun createClientProfile(uid: String, nombre: String, email: String): User = write {
        val profile = User(
            uid = uid,
            nombre = nombre,
            email = email,
            telefono = null,
            rol = UserRole.CLIENTE,
            activo = true,
            createdAt = isoNow(),
        )
        db.collection("usuarios").document(uid).set(userMap(profile)).await()
        profile
    }

    override suspend fun updateUserProfile(uid: String, nombre: String, telefono: String?) {
        write {
            val changes = mapOf<String, Any?>(
                "nombre" to nombre,
                "telefono" to (telefono ?: FieldValue.delete()),
            )
            db.collection("usuarios").document(uid).update(changes).await()
            try {
                val request = UserProfileChangeRequest.Builder().setDisplayName(nombre).build()
                auth.currentUser?.updateProfile(request)?.await()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Solo es el nombre visible en Firebase Authentication; el perfil real ya se guardó.
            }
        }
    }

    override suspend fun deleteUserProfile(uid: String) {
        write { db.collection("usuarios").document(uid).delete().await() }
    }

    // ------------------------------------------------------------------
    // Escuchas en tiempo real
    // ------------------------------------------------------------------

    override fun listenServices(onData: (List<Service>) -> Unit, onError: (AppException) -> Unit): Stop =
        listen(db.collection("servicios"), ::serviceFrom, onError) { items ->
            onData(items.sortedWith(compareBy({ it.createdAt }, { it.nombre.lowercase() })))
        }

    override fun listenBarbers(onData: (List<Barber>) -> Unit, onError: (AppException) -> Unit): Stop =
        listen(db.collection("barberos"), ::barberFrom, onError) { items ->
            onData(items.sortedWith(compareBy({ it.createdAt }, { it.nombre.lowercase() })))
        }

    override fun listenSchedules(onData: (List<Schedule>) -> Unit, onError: (AppException) -> Unit): Stop =
        listen(db.collection("horarios"), ::scheduleFrom, onError) { items ->
            onData(items.sortedWith(compareBy({ it.diaSemana }, { it.horaInicio })))
        }

    override fun listenAppointments(
        user: User,
        onData: (List<Appointment>) -> Unit,
        onError: (AppException) -> Unit,
    ): Stop {
        val base = db.collection("citas")
        // Las consultas deben coincidir con las reglas: gerente = todo; barbero/cliente = solo lo suyo.
        val query: Query = when (user.rol) {
            UserRole.GERENTE -> base
            UserRole.BARBERO -> base.whereEqualTo("barberoId", user.uid)
            UserRole.CLIENTE -> base.whereEqualTo("clienteId", user.uid)
        }
        return listen(query, ::appointmentFrom, onError, onData)
    }

    override fun listenBlocks(fromDate: String, onData: (List<Bloqueo>) -> Unit, onError: (AppException) -> Unit): Stop =
        listen(db.collection("bloqueos").whereGreaterThanOrEqualTo("fecha", fromDate), ::blockFrom, onError, onData)

    private fun <T : Any> listen(
        query: Query,
        map: (DocumentSnapshot) -> T?,
        onError: (AppException) -> Unit,
        onData: (List<T>) -> Unit,
    ): Stop {
        val registration = query.addSnapshotListener(
            EventListener<QuerySnapshot> { snapshot, error ->
                if (error != null) {
                    onError(FirebaseErrors.map(error))
                } else if (snapshot != null) {
                    onData(snapshot.documents.mapNotNull(map))
                }
            },
        )
        return { registration.remove() }
    }

    // ------------------------------------------------------------------
    // Servicios
    // ------------------------------------------------------------------

    override suspend fun saveService(id: String?, input: ServiceInput) {
        write {
            val data = mutableMapOf<String, Any?>(
                "nombre" to input.nombre,
                "precio" to input.precio,
                "duracion" to input.duracion.toLong(),
                "imagen" to input.imagen,
                "activo" to input.activo,
            )
            if (id == null) {
                val ref = db.collection("servicios").document()
                data["id"] = ref.id
                data["createdAt"] = isoNow()
                if (input.descripcion != null) data["descripcion"] = input.descripcion
                ref.set(data).await()
            } else {
                data["descripcion"] = input.descripcion ?: FieldValue.delete()
                db.collection("servicios").document(id).update(data).await()
            }
        }
    }

    override suspend fun setServiceActive(id: String, activo: Boolean) {
        write { db.collection("servicios").document(id).update("activo", activo).await() }
    }

    // ------------------------------------------------------------------
    // Barberos
    // ------------------------------------------------------------------

    override suspend fun createBarber(uid: String, input: BarberInput) {
        write {
            val now = isoNow()
            val email = input.email.orEmpty()
            val batch = db.batch()
            batch.set(
                db.collection("usuarios").document(uid),
                mapOf<String, Any?>(
                    "uid" to uid,
                    "nombre" to input.nombre,
                    "email" to email,
                    "rol" to UserRole.BARBERO.db,
                    "activo" to input.activo,
                    "createdAt" to now,
                ),
            )
            val barber = mutableMapOf<String, Any?>(
                "id" to uid,
                "nombre" to input.nombre,
                "especialidad" to input.especialidad,
                "activo" to input.activo,
                "email" to email,
                "createdAt" to now,
            )
            if (input.descripcion != null) barber["descripcion"] = input.descripcion
            batch.set(db.collection("barberos").document(uid), barber)
            batch.commit().await()
        }
    }

    override suspend fun updateBarber(id: String, input: BarberInput) {
        write {
            val barberRef = db.collection("barberos").document(id)
            val userRef = db.collection("usuarios").document(id)
            val email = input.email?.takeIf { it.isNotEmpty() }

            val barberChanges = mutableMapOf<String, Any?>(
                "nombre" to input.nombre,
                "especialidad" to input.especialidad,
                "activo" to input.activo,
                "descripcion" to (input.descripcion ?: FieldValue.delete()),
            )
            if (email != null) barberChanges["email"] = email

            val batch = db.batch()
            batch.update(barberRef, barberChanges)
            // Si el barbero tiene usuario de acceso, se mantiene sincronizado (nombre, estado y correo).
            if (userRef.get().await().exists()) {
                val userChanges = mutableMapOf<String, Any?>("nombre" to input.nombre, "activo" to input.activo)
                if (email != null) userChanges["email"] = email
                batch.update(userRef, userChanges)
            }
            batch.commit().await()
        }
    }

    override suspend fun setBarberActive(id: String, activo: Boolean) {
        write {
            val userRef = db.collection("usuarios").document(id)
            val batch = db.batch()
            batch.update(db.collection("barberos").document(id), "activo", activo)
            if (userRef.get().await().exists()) batch.update(userRef, "activo", activo)
            batch.commit().await()
        }
    }

    override suspend fun updateBarberProfile(id: String, especialidad: String, descripcion: String?) {
        write {
            val changes = mapOf<String, Any?>(
                "especialidad" to especialidad,
                "descripcion" to (descripcion ?: FieldValue.delete()),
            )
            db.collection("barberos").document(id).update(changes).await()
        }
    }

    // ------------------------------------------------------------------
    // Horarios
    // ------------------------------------------------------------------

    override suspend fun saveSchedules(
        barberoId: String,
        current: List<Schedule>,
        drafts: List<ScheduleDraft>,
    ): List<Schedule> = write {
        val collection = db.collection("horarios")
        val batch = db.batch()
        val keptIds = drafts.mapNotNull { it.id }.toSet()
        for (existing in current) {
            if (existing.id !in keptIds) batch.delete(collection.document(existing.id))
        }
        val result = ArrayList<Schedule>()
        for (draft in drafts) {
            val draftId = draft.id
            if (draftId == null) {
                val ref = collection.document()
                batch.set(
                    ref,
                    mapOf<String, Any?>(
                        "id" to ref.id,
                        "barberoId" to barberoId,
                        "diaSemana" to draft.diaSemana.toLong(),
                        "horaInicio" to draft.horaInicio,
                        "horaFin" to draft.horaFin,
                        "activo" to true,
                    ),
                )
                result.add(Schedule(ref.id, barberoId, draft.diaSemana, draft.horaInicio, draft.horaFin, true))
            } else {
                val original = current.firstOrNull { it.id == draftId } ?: continue
                if (original.horaInicio != draft.horaInicio || original.horaFin != draft.horaFin) {
                    batch.update(
                        collection.document(draftId),
                        mapOf<String, Any?>("horaInicio" to draft.horaInicio, "horaFin" to draft.horaFin),
                    )
                }
                result.add(original.copy(horaInicio = draft.horaInicio, horaFin = draft.horaFin))
            }
        }
        batch.commit().await()
        result
    }

    // ------------------------------------------------------------------
    // Citas
    // ------------------------------------------------------------------

    override suspend fun createAppointment(data: NewAppointment): Appointment = write {
        val citaRef = db.collection("citas").document()
        val cells = blockCells(data.barberoId, data.fecha, data.horaInicio, data.horaFin)
        val blockRefs = cells.map { db.collection("bloqueos").document(it.id) }
        val createdAt = isoNow()
        val payload = mapOf<String, Any?>(
            "clienteId" to data.cliente.uid,
            "clienteNombre" to data.cliente.nombre,
            "clienteTelefono" to (data.cliente.telefono ?: ""),
            "barberoId" to data.barberoId,
            "servicioId" to data.servicioId,
            "fecha" to data.fecha,
            "horaInicio" to data.horaInicio,
            "horaFin" to data.horaFin,
            "precio" to data.precio,
            "duracion" to data.duracionMinutos.toLong(),
            "estado" to AppointmentStatus.PENDIENTE.db,
            "createdAt" to createdAt,
        )

        // La cita y sus bloqueos se guardan juntos. Si algún bloqueo ya existe (otro cliente reservó
        // esa hora), no se escribe nada. La transacción vuelve a comprobarlo en el servidor, así que
        // dos reservas simultáneas nunca pueden quedar las dos.
        val occupied = db.runTransaction(
            Transaction.Function<Boolean> { transaction ->
                var busy = false
                for (ref in blockRefs) {
                    if (transaction.get(ref).exists()) busy = true
                }
                if (!busy) {
                    transaction.set(citaRef, payload)
                    cells.forEachIndexed { index, cell ->
                        transaction.set(
                            blockRefs[index],
                            mapOf<String, Any?>(
                                "barberoId" to data.barberoId,
                                "fecha" to data.fecha,
                                "hora" to cell.hora,
                                "clienteId" to data.cliente.uid,
                                "citaId" to citaRef.id,
                            ),
                        )
                    }
                }
                busy
            },
        ).await()
        if (occupied) throw AppException("Ese horario ya fue ocupado. Elige otro.")

        Appointment(
            id = citaRef.id,
            clienteId = data.cliente.uid,
            barberoId = data.barberoId,
            servicioId = data.servicioId,
            fecha = data.fecha,
            horaInicio = data.horaInicio,
            horaFin = data.horaFin,
            precio = data.precio,
            duracion = data.duracionMinutos,
            estado = AppointmentStatus.PENDIENTE,
            createdAt = createdAt,
            clienteNombre = data.cliente.nombre,
            clienteTelefono = data.cliente.telefono ?: "",
        )
    }

    override suspend fun setAppointmentStatus(id: String, estado: AppointmentStatus, release: List<Bloqueo>) {
        write {
            val batch = db.batch()
            // Solo se toca el campo "estado": es lo único que las reglas permiten a clientes y barberos.
            batch.update(db.collection("citas").document(id), "estado", estado.db)
            for (block in release) batch.delete(db.collection("bloqueos").document(block.id))
            batch.commit().await()
        }
    }

    // ------------------------------------------------------------------
    // Utilidades
    // ------------------------------------------------------------------

    /**
     * Las escrituras de Firestore sin conexión se quedan en cola y la tarea no termina hasta que
     * vuelve Internet; para que la pantalla no se quede cargando, se comprueba la red antes y se
     * limita el tiempo de espera.
     */
    private suspend fun <T> write(block: suspend () -> T): T {
        if (!isOnline()) throw AppException(FirebaseErrors.NO_CONNECTION)
        try {
            return withTimeout(WRITE_TIMEOUT_MS) { block() }
        } catch (e: TimeoutCancellationException) {
            throw AppException("Firebase tardó demasiado en responder. Revisa tu conexión e inténtalo de nuevo.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: AppException) {
            throw e
        } catch (e: Exception) {
            throw FirebaseErrors.map(e)
        }
    }

    private fun isOnline(): Boolean {
        val manager = context.getSystemService(ConnectivityManager::class.java) ?: return true
        val network = manager.activeNetwork ?: return false
        val capabilities = manager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private companion object {
        const val SECONDARY_APP_NAME = "barbely-alta-barberos"
        const val WRITE_TIMEOUT_MS = 25_000L
    }
}

// ----------------------------------------------------------------------
// Conversión de documentos de Firestore a modelos (tolerante con datos escritos a mano en la consola)
// ----------------------------------------------------------------------

internal fun isoNow(): String = Instant.now().truncatedTo(ChronoUnit.MILLIS).toString()

private fun DocumentSnapshot.text(field: String): String? = when (val value = get(field)) {
    null -> null
    is String -> value
    is Number, is Boolean -> value.toString()
    is Timestamp -> value.toDate().toInstant().toString()
    else -> null
}

private fun DocumentSnapshot.number(field: String): Double? = when (val value = get(field)) {
    is Number -> value.toDouble()
    is String -> value.trim().replace(',', '.').toDoubleOrNull()
    else -> null
}

private fun DocumentSnapshot.flag(field: String, default: Boolean): Boolean =
    (get(field) as? Boolean) ?: default

private fun userMap(user: User): Map<String, Any?> {
    val map = mutableMapOf<String, Any?>(
        "uid" to user.uid,
        "nombre" to user.nombre,
        "email" to user.email,
        "rol" to user.rol.db,
        "activo" to user.activo,
        "createdAt" to user.createdAt,
    )
    if (user.telefono != null) map["telefono"] = user.telefono
    return map
}

private fun userFrom(doc: DocumentSnapshot, authUser: FirebaseUser?): User = User(
    uid = doc.id,
    nombre = doc.text("nombre") ?: authUser?.displayName ?: "Usuario",
    email = doc.text("email") ?: authUser?.email.orEmpty(),
    telefono = doc.text("telefono")?.takeIf { it.isNotEmpty() },
    rol = UserRole.from(doc.text("rol")),
    activo = doc.flag("activo", true),
    createdAt = doc.text("createdAt").orEmpty(),
)

private fun barberFrom(doc: DocumentSnapshot): Barber = Barber(
    id = doc.id,
    nombre = doc.text("nombre") ?: "Barbero",
    descripcion = doc.text("descripcion")?.takeIf { it.isNotEmpty() },
    especialidad = doc.text("especialidad").orEmpty(),
    calificacionPromedio = doc.number("calificacionPromedio"),
    activo = doc.flag("activo", true),
    createdAt = doc.text("createdAt").orEmpty(),
    email = doc.text("email")?.takeIf { it.isNotEmpty() },
)

private fun serviceFrom(doc: DocumentSnapshot): Service = Service(
    id = doc.id,
    nombre = doc.text("nombre") ?: "Servicio",
    descripcion = doc.text("descripcion")?.takeIf { it.isNotEmpty() },
    precio = doc.number("precio") ?: 0.0,
    duracion = doc.number("duracion")?.toInt() ?: 30,
    activo = doc.flag("activo", true),
    createdAt = doc.text("createdAt").orEmpty(),
    imagen = doc.text("imagen")?.trim()?.takeIf { it.isNotEmpty() },
)

private fun scheduleFrom(doc: DocumentSnapshot): Schedule? {
    val barberoId = doc.text("barberoId") ?: return null
    val dia = doc.number("diaSemana")?.toInt() ?: return null
    val inicio = doc.text("horaInicio") ?: return null
    val fin = doc.text("horaFin") ?: return null
    return Schedule(doc.id, barberoId, dia, inicio, fin, doc.flag("activo", true))
}

private fun appointmentFrom(doc: DocumentSnapshot): Appointment? {
    val clienteId = doc.text("clienteId") ?: return null
    val barberoId = doc.text("barberoId") ?: return null
    val fecha = doc.text("fecha") ?: return null
    val inicio = doc.text("horaInicio") ?: return null
    val fin = doc.text("horaFin") ?: return null
    return Appointment(
        id = doc.id,
        clienteId = clienteId,
        barberoId = barberoId,
        servicioId = doc.text("servicioId").orEmpty(),
        fecha = fecha,
        horaInicio = inicio,
        horaFin = fin,
        precio = doc.number("precio") ?: 0.0,
        duracion = doc.number("duracion")?.toInt() ?: 30,
        estado = AppointmentStatus.from(doc.text("estado")),
        createdAt = doc.text("createdAt").orEmpty(),
        clienteNombre = doc.text("clienteNombre")?.takeIf { it.isNotEmpty() },
        clienteTelefono = doc.text("clienteTelefono")?.takeIf { it.isNotEmpty() },
    )
}

private fun blockFrom(doc: DocumentSnapshot): Bloqueo? {
    val barberoId = doc.text("barberoId") ?: return null
    val fecha = doc.text("fecha") ?: return null
    val hora = doc.text("hora") ?: return null
    return Bloqueo(
        id = doc.id,
        barberoId = barberoId,
        fecha = fecha,
        hora = hora,
        clienteId = doc.text("clienteId").orEmpty(),
        citaId = doc.text("citaId").orEmpty(),
    )
}
