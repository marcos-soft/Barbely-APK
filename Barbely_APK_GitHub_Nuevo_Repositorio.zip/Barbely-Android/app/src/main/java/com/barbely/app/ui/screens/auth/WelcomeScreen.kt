package com.barbely.app.ui.screens.auth

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.barbely.app.R
import com.barbely.app.ui.components.BButton
import com.barbely.app.ui.components.BText
import com.barbely.app.ui.components.ButtonVariant
import com.barbely.app.ui.nav.LocalNav
import com.barbely.app.ui.nav.Route
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BType

@Composable
fun WelcomeScreen() {
    val nav = LocalNav.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BColors.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(24.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Image(
                painter = painterResource(id = R.drawable.logo_mark),
                contentDescription = null,
                modifier = Modifier.padding(bottom = 8.dp).size(width = 78.dp, height = 56.dp),
                contentScale = ContentScale.Fit,
            )
            BText("Reserva tu corte\nsin llamadas ni esperas", BType.display, BColors.textPrimary)
            BText(
                text = "Elige barbero, servicio y horario disponible en un par de toques.",
                style = BType.bodyLarge,
                color = BColors.textSecondary,
                modifier = Modifier.widthIn(max = 320.dp),
            )
        }
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            BButton(label = "Crear cuenta", onClick = { nav.push(Route.Register) })
            BButton(
                label = "Ya tengo cuenta",
                onClick = { nav.push(Route.Login) },
                variant = ButtonVariant.Secondary,
            )
        }
    }
}
