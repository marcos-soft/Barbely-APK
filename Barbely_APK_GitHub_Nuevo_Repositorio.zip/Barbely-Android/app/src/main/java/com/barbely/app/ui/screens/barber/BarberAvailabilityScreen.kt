package com.barbely.app.ui.screens.barber

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.imePadding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.barbely.app.ui.components.BHeader
import com.barbely.app.ui.components.ScheduleEditor
import com.barbely.app.ui.nav.LocalApp
import com.barbely.app.ui.theme.BColors

@Composable
fun BarberAvailabilityScreen() {
    val app = LocalApp.current
    val barber = app.currentBarber()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BColors.background)
            .navigationBarsPadding()
            .imePadding(),
    ) {
        BHeader(title = "Mi disponibilidad")
        ScheduleEditor(barberoId = barber.id)
    }
}
