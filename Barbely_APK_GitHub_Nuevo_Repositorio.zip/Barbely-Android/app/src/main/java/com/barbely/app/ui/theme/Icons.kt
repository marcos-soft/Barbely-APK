package com.barbely.app.ui.theme

import com.barbely.app.R

/** Íconos de Ionicons (los mismos de la versión original), convertidos a vectores de Android. */
object BIcons {
    val Add = R.drawable.ic_add
    val AlertCircle = R.drawable.ic_alert_circle_outline
    val Briefcase = R.drawable.ic_briefcase_outline
    val Calendar = R.drawable.ic_calendar_outline
    val Call = R.drawable.ic_call_outline
    val Checkmark = R.drawable.ic_checkmark
    val CheckmarkCircle = R.drawable.ic_checkmark_circle
    val ChevronBack = R.drawable.ic_chevron_back
    val ChevronForward = R.drawable.ic_chevron_forward
    val Close = R.drawable.ic_close
    val CloseCircle = R.drawable.ic_close_circle_outline
    val Cut = R.drawable.ic_cut_outline
    val DocumentText = R.drawable.ic_document_text_outline
    val Eye = R.drawable.ic_eye_outline
    val EyeOff = R.drawable.ic_eye_off_outline
    val Grid = R.drawable.ic_grid_outline
    val Home = R.drawable.ic_home_outline
    val ListIcon = R.drawable.ic_list_outline
    val LockClosed = R.drawable.ic_lock_closed_outline
    val Mail = R.drawable.ic_mail_outline
    val People = R.drawable.ic_people_outline
    val Person = R.drawable.ic_person_outline
    val Pricetag = R.drawable.ic_pricetag_outline
    val Star = R.drawable.ic_star
    val Time = R.drawable.ic_time_outline
    val Trash = R.drawable.ic_trash_outline
}
