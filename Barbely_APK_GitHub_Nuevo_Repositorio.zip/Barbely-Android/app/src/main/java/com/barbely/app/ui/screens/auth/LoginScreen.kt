package com.barbely.app.ui.screens.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.barbely.app.ui.components.BButton
import com.barbely.app.ui.components.BInput
import com.barbely.app.ui.components.BText
import com.barbely.app.ui.components.rememberActionRunner
import com.barbely.app.ui.components.tappable
import com.barbely.app.ui.nav.LocalApp
import com.barbely.app.ui.nav.LocalNav
import com.barbely.app.ui.nav.Route
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BIcons
import com.barbely.app.ui.theme.BType

@Composable
fun LoginScreen() {
    val app = LocalApp.current
    val nav = LocalNav.current
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var formError by remember { mutableStateOf<String?>(null) }
    val action = rememberActionRunner()

    fun submit() {
        formError = null
        if (email.trim().isEmpty() || password.isEmpty()) {
            formError = "Completa tu correo y contraseña."
            return
        }
        action.run(onError = { formError = it }) {
            app.signIn(email.trim(), password)
            nav.resetTo(Route.Home)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BColors.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        Column(modifier = Modifier.padding(bottom = 24.dp)) {
            BText("Inicia sesión", BType.h1, BColors.textPrimary)
            BText(
                "Bienvenido de nuevo a BARBELY", BType.body, BColors.textSecondary,
                Modifier.padding(top = 4.dp),
            )
        }

        BInput(
            value = email,
            onValueChange = { email = it },
            label = "Correo electrónico",
            placeholder = "tucorreo@ejemplo.com",
            leftIcon = BIcons.Mail,
            keyboardType = KeyboardType.Email,
            capitalization = KeyboardCapitalization.None,
        )
        BInput(
            value = password,
            onValueChange = { password = it },
            label = "Contraseña",
            placeholder = "••••••••",
            secure = true,
            leftIcon = BIcons.LockClosed,
            keyboardType = KeyboardType.Password,
            capitalization = KeyboardCapitalization.None,
        )
        val message = formError
        if (message != null) {
            BText(message, BType.caption, BColors.danger, Modifier.padding(bottom = 8.dp))
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.End,
        ) {
            BText(
                text = "¿Olvidaste tu contraseña?",
                style = BType.captionMedium,
                color = BColors.gold,
                modifier = Modifier.tappable { nav.push(Route.ForgotPassword) },
            )
        }

        BButton(label = "Iniciar sesión", onClick = { submit() }, loading = action.running)

        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 24.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BText("¿No tienes cuenta? ", BType.body, BColors.textSecondary)
            BText(
                text = "Regístrate",
                style = BType.captionMedium,
                color = BColors.gold,
                modifier = Modifier.tappable { nav.push(Route.Register) },
            )
        }
    }
}
