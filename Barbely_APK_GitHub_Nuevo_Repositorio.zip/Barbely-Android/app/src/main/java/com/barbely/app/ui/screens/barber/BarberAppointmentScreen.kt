package com.barbely.app.ui.screens.barber

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.barbely.app.data.AppointmentStatus
import com.barbely.app.logic.formatFechaLarga
import com.barbely.app.logic.money
import com.barbely.app.ui.components.BButton
import com.barbely.app.ui.components.BHeader
import com.barbely.app.ui.components.BModal
import com.barbely.app.ui.components.BText
import com.barbely.app.ui.components.ButtonVariant
import com.barbely.app.ui.components.ErrorState
import com.barbely.app.ui.components.InfoCard
import com.barbely.app.ui.components.InfoRow
import com.barbely.app.ui.components.LoadingState
import com.barbely.app.ui.components.StatusBadge
import com.barbely.app.ui.components.rememberActionRunner
import com.barbely.app.ui.nav.LocalApp
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BIcons
import com.barbely.app.ui.theme.BType

@Composable
fun BarberAppointmentScreen(appointmentId: String) {
    val app = LocalApp.current
    val context = LocalContext.current
    val appointment = app.appointment(appointmentId)
    var cancelVisible by remember { mutableStateOf(false) }
    var statusError by remember { mutableStateOf<String?>(null) }
    var pendingStatus by remember { mutableStateOf<AppointmentStatus?>(null) }
    val action = rememberActionRunner()

    if (appointment == null) {
        Column(modifier = Modifier.fillMaxSize().background(BColors.background)) {
            BHeader(title = "Cita")
            if (!app.dataReady) {
                LoadingState("Cargando cita…")
            } else {
                ErrorState(title = "Cita no encontrada")
            }
        }
        return
    }

    fun changeStatus(status: AppointmentStatus) {
        statusError = null
        pendingStatus = status
        action.run(
            onError = {
                statusError = it
                cancelVisible = false
            },
        ) {
            app.updateAppointmentStatus(appointment.id, status)
            cancelVisible = false
        }
    }

    fun call(phone: String) {
        try {
            context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(phone))))
        } catch (e: Exception) {
            // Dispositivo sin aplicación de teléfono: no hay nada que hacer.
        }
    }

    val phone = appointment.clienteTelefono
    val canAct = appointment.estado == AppointmentStatus.PENDIENTE ||
        appointment.estado == AppointmentStatus.CONFIRMADA

    Box(modifier = Modifier.fillMaxSize().background(BColors.background)) {
        Column(modifier = Modifier.fillMaxSize().navigationBarsPadding()) {
            BHeader(title = "Detalle de la cita")
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    BText(
                        text = appointment.servicio?.nombre ?: "Servicio",
                        style = BType.h1,
                        color = BColors.textPrimary,
                        modifier = Modifier.weight(1f).padding(end = 12.dp),
                    )
                    StatusBadge(appointment.estado)
                }

                InfoCard {
                    InfoRow(BIcons.Person, "Cliente", appointment.clienteNombre ?: "—")
                    if (!phone.isNullOrEmpty()) {
                        InfoRow(BIcons.Call, "Teléfono", phone, onClick = { call(phone) })
                    }
                    InfoRow(BIcons.Calendar, "Fecha", formatFechaLarga(appointment.fecha))
                    InfoRow(BIcons.Time, "Hora", "${appointment.horaInicio} – ${appointment.horaFin}")
                    InfoRow(BIcons.Pricetag, "Precio", money(appointment.precio))
                }

                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    val problem = statusError
                    if (problem != null) {
                        BText(problem, BType.caption, BColors.danger)
                    }
                    if (appointment.estado == AppointmentStatus.PENDIENTE) {
                        BButton(
                            label = "Confirmar cita",
                            onClick = { changeStatus(AppointmentStatus.CONFIRMADA) },
                            loading = action.running && pendingStatus == AppointmentStatus.CONFIRMADA,
                            enabled = !action.running,
                        )
                    }
                    if (appointment.estado == AppointmentStatus.CONFIRMADA) {
                        BButton(
                            label = "Marcar como completada",
                            onClick = { changeStatus(AppointmentStatus.COMPLETADA) },
                            loading = action.running && pendingStatus == AppointmentStatus.COMPLETADA,
                            enabled = !action.running,
                        )
                    }
                    if (canAct) {
                        BButton(
                            label = "Cancelar cita",
                            onClick = {
                                statusError = null
                                cancelVisible = true
                            },
                            variant = ButtonVariant.Danger,
                            enabled = !action.running,
                        )
                    }
                }
            }
        }

        BModal(
            visible = cancelVisible,
            onClose = { if (!action.running) cancelVisible = false },
            title = "¿Cancelar esta cita?",
        ) {
            BText(
                text = "La cita de ${appointment.clienteNombre ?: "el cliente"} quedará cancelada y se liberará el horario.",
                style = BType.body,
                color = BColors.textSecondary,
                modifier = Modifier.padding(bottom = 20.dp),
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BButton(
                    label = "Volver",
                    onClick = { cancelVisible = false },
                    modifier = Modifier.weight(1f),
                    variant = ButtonVariant.Ghost,
                    fullWidth = false,
                    enabled = !action.running,
                )
                BButton(
                    label = "Sí, cancelar",
                    onClick = { changeStatus(AppointmentStatus.CANCELADA) },
                    modifier = Modifier.weight(1f),
                    variant = ButtonVariant.Danger,
                    fullWidth = false,
                    loading = action.running,
                )
            }
        }
    }
}
