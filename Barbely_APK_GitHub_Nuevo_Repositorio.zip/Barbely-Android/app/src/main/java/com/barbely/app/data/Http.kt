package com.barbely.app.data

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

/** Descarga sencilla por HTTPS (fotos de servicios). Debe llamarse desde un hilo de fondo. */
internal object Http {

    /** Lee como máximo [maxBytes]; si el archivo es más grande lanza [AppException] [tooBig]. */
    fun readLimited(input: InputStream, maxBytes: Int, tooBig: String): ByteArray {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(16 * 1024)
        var total = 0
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            total += read
            if (total > maxBytes) throw AppException(tooBig)
            out.write(buffer, 0, read)
        }
        return out.toByteArray()
    }

    fun download(rawUrl: String, maxBytes: Int): ByteArray {
        val url = try {
            URL(rawUrl.trim())
        } catch (e: IOException) {
            throw AppException("El enlace no es válido.")
        }
        if (!url.protocol.equals("https", ignoreCase = true)) {
            throw AppException("Usa un enlace que empiece con https://")
        }
        val connection = url.openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 10_000
            connection.readTimeout = 15_000
            connection.instanceFollowRedirects = true
            connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) Barbely/1.0")
            connection.setRequestProperty("Accept", "image/*")
            val code = connection.responseCode
            if (code !in 200..299) throw AppException("No se pudo descargar la imagen (error $code).")
            return connection.inputStream.use {
                readLimited(it, maxBytes, "La imagen es demasiado grande.")
            }
        } catch (e: AppException) {
            throw e
        } catch (e: IOException) {
            throw AppException("No se pudo descargar la imagen. Revisa el enlace y tu conexión.")
        } finally {
            connection.disconnect()
        }
    }
}
