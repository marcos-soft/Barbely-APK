package com.barbely.app.data

import com.google.android.gms.tasks.Task
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

/**
 * Convierte una Task de Google Play Services (lo que devuelve Firebase) en una función `suspend`,
 * así no hace falta la librería extra kotlinx-coroutines-play-services.
 */
internal suspend fun <T> Task<T>.await(): T = suspendCancellableCoroutine { continuation ->
    addOnCompleteListener { task ->
        when {
            task.isCanceled -> continuation.cancel()
            task.isSuccessful -> {
                // `result` puede venir como T? según la versión de Play Services; el cast sirve para ambas.
                @Suppress("UNCHECKED_CAST")
                continuation.resume(task.result as T)
            }
            else -> continuation.resumeWithException(
                task.exception ?: IllegalStateException("La operación de Firebase falló sin detalles."),
            )
        }
    }
}
