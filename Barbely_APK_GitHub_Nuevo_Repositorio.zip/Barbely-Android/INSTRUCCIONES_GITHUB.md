# Barbely — generar APK en GitHub Actions

## Crear un repositorio nuevo
1. En GitHub crea un repositorio vacío llamado `Barbely-APK` (sin README, licencia ni `.gitignore` inicial).
2. Extrae este ZIP en una computadora. Sube el CONTENIDO de la carpeta `Barbely-Android` a la raíz del repositorio; no subas el ZIP como un único archivo y no dejes una carpeta `Barbely-Android` anidada dentro de la raíz.
3. Confirma la subida en la rama `main`.
4. Abre la pestaña **Actions** del repositorio. El flujo **Generar APK de Barbely** se ejecuta al subir a `main`; también puedes abrirlo y pulsar **Run workflow**.
5. Espera que la ejecución termine con marca verde. Abre la ejecución y descarga el artefacto `Barbely-APK-Android` de la sección **Artifacts**.
6. Extrae el ZIP del artefacto. `app-debug.apk` es para pruebas. `app-release.apk` también se firma con la clave de depuración según la configuración actual; no es una firma de publicación de Google Play.

## Importante
- Este flujo compila los APK; no publica las reglas de Firestore automáticamente.
- La configuración de Firebase apunta al proyecto `barbely-56710` y la app usa el paquete Android `com.barbely.app`.
- La compilación todavía debe comprobarse en GitHub. Si falla, abre el registro de la ejecución y revisa el primer error de Gradle/Kotlin.
- No subas contraseñas, claves privadas ni archivos de firma. No reemplaces el repositorio anterior: este debe ser uno nuevo para mantenerlo separado.
