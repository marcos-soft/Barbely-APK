# Barbely — proyecto Android Studio (Kotlin + Jetpack Compose + Firebase)

App de citas para barbería con **3 roles** (cliente, barbero, gerente) que usa **el mismo proyecto de Firebase de tu app original** (`barbely-56710`: Authentication + Cloud Firestore). Tus usuarios, barberos, servicios, horarios y citas de siempre siguen ahí.

- Nativa: Kotlin 2.0.21 · Jetpack Compose (Material 3) · `minSdk 26` · `targetSdk/compileSdk 35`
- Paquete: `com.barbely.app`
- Gradle 8.9 (wrapper incluido) · Android Gradle Plugin 8.7.0 · JDK 17 (el que trae Android Studio sirve)
- Firebase Android SDK (BoM 33.7.0): solo `firebase-auth` y `firebase-firestore`

---

## 1. Abrir el proyecto y generar el APK

1. Instala **Android Studio Ladybug (2024.2.1) o más nuevo**.
2. **File ▸ Open…** y elige la carpeta `Barbely-Android` (la que contiene `settings.gradle.kts`).
3. Espera a que termine **Gradle Sync** (la primera vez descarga Gradle y las librerías: necesita Internet y tarda unos minutos). Si Android Studio ofrece actualizar el plugin de Gradle, puedes decir que no: el proyecto ya está configurado.
4. **Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)**. Al terminar aparece el aviso *"APK(s) generated successfully"* con el enlace **locate**. El archivo queda en:
   `app/build/outputs/apk/debug/app-debug.apk`
5. Para probarlo: conecta el celular con **Depuración USB** y pulsa **Run ▶**, o copia el `.apk` al celular e instálalo (permite "instalar apps de orígenes desconocidos"). También funciona en el emulador (necesita una imagen con Google Play / Internet).

Desde la terminal (en la carpeta del proyecto):

```
./gradlew assembleDebug        # Windows: gradlew.bat assembleDebug
./gradlew assembleRelease      # app/build/outputs/apk/release/app-release.apk
```

El APK *release* queda firmado con la llave de depuración, así que se puede instalar directamente (sirve para entregar el módulo; para publicar en Play Store habría que firmarlo con tu propia llave).

---

## 2. Antes de usarla: 2 cosas obligatorias en Firebase

### 2.1 Publicar las reglas de seguridad (¡las de prueba ya vencieron!)

El correo de Firebase avisaba que el acceso de clientes a Firestore vencía en 0 días: cuando vence, **todas** las lecturas y escrituras se rechazan (`PERMISSION_DENIED`) y la app no carga nada. Las reglas correctas están en `firebase/firestore.rules` (son las mismas de tu app original: cada rol solo puede hacer lo que le corresponde).

**Opción A — desde la consola (la más fácil):**
1. [console.firebase.google.com](https://console.firebase.google.com) ▸ proyecto **Barbely** ▸ **Firestore Database** ▸ pestaña **Reglas**.
2. Borra lo que haya, pega todo el contenido de `firebase/firestore.rules` y pulsa **Publicar**.

**Opción B — con la CLI de Firebase:**
```
cd firebase
firebase login
firebase deploy --only firestore:rules --project barbely-56710
```

### 2.2 Activar el acceso con correo y contraseña

Firebase Console ▸ **Authentication** ▸ **Sign-in method** ▸ **Correo electrónico/contraseña** ▸ **Habilitar** (si tu app original ya iniciaba sesión así, ya está activo).

---

## 3. Opcional: `google-services.json`

**No es necesario**: la app se conecta con los datos del proyecto que están en `data/FirebaseConfig.kt`. Pero si al iniciar sesión te sale *"Requests from this Android client application are blocked"* o *"API key not valid"* (la llave de la app web tiene restricciones), registra la app Android y agrega el archivo:

1. Firebase Console ▸ ⚙ **Configuración del proyecto** ▸ **Tus apps** ▸ **Agregar app** ▸ Android.
2. Nombre del paquete: `com.barbely.app`.
3. (Recomendado) Agrega la huella **SHA-1** de depuración. En Android Studio: pestaña **Gradle** ▸ `Barbely-Android ▸ Tasks ▸ android ▸ signingReport`, y copia el `SHA1` de la variante `debug`.
4. Descarga `google-services.json` y cópialo dentro de la carpeta `app/` (junto a `app/build.gradle.kts`).
5. **File ▸ Sync Project with Gradle Files** y vuelve a generar el APK. El proyecto detecta el archivo y activa el plugin de Google Services automáticamente.

---

## 4. Primer gerente

Si en tu base de datos ya existe una cuenta con rol `gerente`, **úsala tal cual**: todas las cuentas viejas (clientes, barberos, gerente) siguen funcionando con su mismo correo y contraseña.

Si no tienes ninguna:
1. Firebase Console ▸ **Authentication ▸ Users ▸ Add user** (correo + contraseña). Copia el **UID** del usuario.
2. **Firestore Database ▸ colección `usuarios` ▸ Agregar documento**, con **ID del documento = ese UID**, y estos campos:

| Campo | Tipo | Valor |
|---|---|---|
| `nombre` | string | Tu nombre |
| `email` | string | El mismo correo |
| `rol` | string | `gerente` |
| `activo` | boolean | `true` |

3. Inicia sesión en la app con ese correo. Desde el panel del gerente creas **servicios**, **barberos** (la app les crea su cuenta con correo y contraseña) y ves todas las citas.

Los clientes se registran solos desde la pantalla "Crear cuenta" (siempre entran con rol `cliente`).

---

## 5. Fotos de referencia en los servicios (lo que pidió el profesor)

- **Cliente:** cada servicio muestra su foto en la lista, en el detalle (foto grande: *"así queda el corte / la barba"*), al reservar y en **Mis citas**.
- **Gerente:** pestaña **Gestión** ▸ **Servicios** ▸ **Nuevo servicio** (o toca uno para editarlo) ▸ sección **Foto de referencia**:
  - **Elegir foto**: abre la galería del celular. La app la corrige (orientación), la reduce a máximo 800 px y la comprime a ≤ 300 KB antes de guardarla.
  - **Pegar enlace**: pega un enlace que empiece con `https://` ▸ **Descargar y usar esta foto**.
  - **Quitar foto**: vuelve a la ilustración.
- La foto se guarda **dentro del documento del servicio en Firestore** (campo `imagen`, como texto Base64). Así no hace falta Firebase Storage (que ya es de pago) y funciona con tu plan actual. Por eso el tamaño está limitado: un documento de Firestore admite máximo 1 MiB.
- **Imágenes por defecto:** si un servicio no tiene foto, se muestra una **ilustración** según su nombre (corte, barba, fade/degradado, afeitado, cejas, combo, infantil, color) con la etiqueta *"Imagen ilustrativa"*. Con foto real la etiqueta dice *"Foto de referencia"*. Las ilustraciones son dibujos, **no fotos reales**: para que el profesor vea fotos de verdad, sube una foto a cada servicio desde la app, o reemplaza los archivos `app/src/main/res/drawable-nodpi/svc_*.webp` (1200×900) por fotos tuyas con el mismo nombre.

---

## 6. Problemas comunes

| Síntoma | Causa y solución |
|---|---|
| *"Firestore rechazó la operación (permiso denegado)…"* / la app no carga datos | Las reglas no están publicadas o siguen vencidas → sección 2.1. También ocurre si el documento `usuarios/{uid}` de esa cuenta no existe o tiene un `rol` mal escrito (debe ser `cliente`, `barbero` o `gerente`). |
| *"No hay conexión con Firebase. Revisa Internet."* | Revisa Internet del celular o emulador. Si el emulador no tiene red, reinícialo (Cold Boot). |
| *"Requests from this Android client application are blocked"* o *"API key not valid"* | La llave tiene restricciones → sección 3 (registrar la app Android + `google-services.json`), o quita la restricción de aplicación de esa llave en Google Cloud Console ▸ APIs y servicios ▸ Credenciales. |
| *"El acceso con correo y contraseña no está activado en Firebase…"* | Falta habilitar Correo/Contraseña → sección 2.2. |
| *"Esta cuenta está desactivada."* | El campo `activo` del usuario es `false`; el gerente (o la consola) debe ponerlo en `true`. |
| Gradle: *"Could not resolve …"* | Sin Internet durante el Sync, o proxy/VPN de la escuela bloqueando `dl.google.com` / `repo.maven.apache.org`. Prueba con otra red y **File ▸ Sync**. |
| Gradle: *"Unsupported class file major version"* / error de JDK | En **Settings ▸ Build, Execution, Deployment ▸ Build Tools ▸ Gradle ▸ Gradle JDK** elige el **jbr-17** (o 21) que trae Android Studio. |
| *"SDK location not found"* | Android Studio crea `local.properties` solo al abrir el proyecto; si falta, instala el SDK 35 desde **Tools ▸ SDK Manager** y vuelve a sincronizar. |

---

## 7. Qué cambió respecto a la versión anterior (SQLite)

- La base **local SQLite se eliminó**; ahora todo vive en Firebase (Authentication + Firestore), igual que tu app Expo original, con las mismas colecciones: `usuarios`, `barberos`, `servicios` (campo `imagen` para la foto), `horarios`, `citas` y `bloqueos`.
- **Desaparecieron las cuentas demo** de la versión SQLite: ahora se entra con las cuentas reales de Firebase.
- Las citas se reservan con una **transacción**: si dos clientes eligen la misma hora al mismo tiempo, solo uno la consigue y el otro recibe *"Ese horario ya fue ocupado. Elige otro."*
- Cambios en tiempo real: si el barbero confirma una cita o alguien reserva, los demás teléfonos se actualizan solos.
- **Eliminar mi cuenta** (cliente, pestaña Perfil): cancela las citas próximas, libera los horarios y borra el perfil y la cuenta (pide la contraseña para confirmar).
- Si no hay Internet o la escritura tarda más de 25 s, la app avisa con un mensaje claro y no deja datos a medias.
- El respaldo con SQLite sigue en el ZIP anterior (`Barbely_Android_Studio.zip`) por si lo necesitas.

---

## 8. Estructura del código

```
app/src/main/java/com/barbely/app/
├── BarbelyApplication.kt     inicia Firebase y el estado global
├── MainActivity.kt
├── data/                     FirebaseBackend (Auth + Firestore), FirebaseConfig, modelos, errores, procesado de fotos
├── logic/                    disponibilidad de horarios, celdas de 15 min, fechas/horas, reducción de imágenes, ilustración por servicio
├── state/AppState.kt         sesión, listas en tiempo real y acciones (reservar, cancelar, CRUD del gerente…)
└── ui/                       tema, componentes y pantallas (auth / client / barber / manager)
firebase/                     firestore.rules + firebase.json (para publicar las reglas)
```

---

## 9. Qué se probó y qué no (honestidad)

Esta versión se preparó en un entorno **sin acceso a los servidores de Google/Maven**, así que:

**Sí se verificó**
- El código completo se compiló con el compilador de Kotlin 2.0.21 contra las firmas de las librerías (0 errores).
- Se ejecutó la lógica real de la app (`FirebaseBackend`, `AppState`, disponibilidad, fotos) contra un Firebase simulado, **incluyendo las reglas de `firestore.rules` interpretadas tal cual**: registro/login, recuperar sesión, cuentas desactivadas, sin Internet, reglas vencidas, servicios con foto, creación de barberos, horarios, reservas, dos clientes a la vez por la misma hora, cada rol viendo solo lo suyo, cancelar/confirmar, eliminar cuenta, sincronización entre teléfonos y la matriz de seguridad de las reglas — 1077 comprobaciones, 0 fallas. Se comprobó además que las pruebas fallan cuando se rompe el código a propósito.

**No se pudo verificar aquí (pruébalo tú)**
- La **compilación real con Gradle y la generación del APK** (necesitan descargar dependencias de Google).
- La conexión a tu **Firebase real**: depende de que publiques las reglas (sección 2.1) y de las restricciones de tu llave de API (sección 3).
- El aspecto visual en un celular/emulador real (la interfaz solo se revisó a nivel de compilación) y la galería/descarga de fotos en el dispositivo.
- Las ilustraciones por defecto son dibujos, no fotos reales (sección 5).
- Al editar un barbero, cambiar su correo solo actualiza el dato mostrado; no cambia el correo con el que inicia sesión (eso requiere el Admin SDK de Firebase).

Si algo falla al compilar, copia el mensaje exacto de la pestaña **Build**; si falla al conectar, copia el texto del aviso que muestra la app. Con eso se corrige rápido.
