// Archivo de build de nivel superior: aquí solo se declaran las versiones de los plugins.
plugins {
    id("com.android.application") version "8.7.0" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
    // Solo se usa si agregas app/google-services.json (ver app/build.gradle.kts).
    id("com.google.gms.google-services") version "4.4.2" apply false
}
